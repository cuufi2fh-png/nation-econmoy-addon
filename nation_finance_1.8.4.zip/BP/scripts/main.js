import { world, system } from "@minecraft/server";
import { ModalFormData, ActionFormData } from "@minecraft/server-ui";

// ====== V0.1: 국가 생성 로직 ======
function getNextNationId() {
    let id = world.getDynamicProperty("nextNationId");
    if (id === undefined) id = 1;
    world.setDynamicProperty("nextNationId", id + 1);
    return id;
}

world.beforeEvents.itemUse.subscribe((event) => {
    const item = event.itemStack;
    const player = event.source;

    if (item.typeId.includes("banner")) {
        const nationName = item.nameTag;
        if (nationName && nationName !== "" && !nationName.includes("Banner") && !nationName.includes("현수막")) {
            if (player.hasTag("has_nation")) {
                system.run(() => { player.sendMessage("§c이미 소속된 국가가 있습니다!"); });
                return;
            }
            event.cancel = true;
            system.run(() => {
                const currentNationId = getNextNationId();
                const nId = "nation_id_" + currentNationId;
                player.addTag("has_nation");
                player.addTag("nation_leader");
                player.addTag(nId);
                player.runCommand(`scoreboard players set @s nation_id ${currentNationId}`);
                player.runCommand(`tellraw @a {"rawtext":[{"text":"§e[공지] §a${player.name}§f님이 §b${nationName}§f 국가를 건국했습니다!"}]}`);
                player.runCommand(`function nation/create`);
                
                let currencies = JSON.parse(world.getDynamicProperty("currencies") || "{}");
                currencies[nId] = { symbol: "COIN", supply: 100000, rate: 1.0, tax_rate: 50 };
                world.setDynamicProperty("currencies", JSON.stringify(currencies));
                
                let nationNames = JSON.parse(world.getDynamicProperty("nation_names") || "{}");
                nationNames[nId] = nationName;
                world.setDynamicProperty("nation_names", JSON.stringify(nationNames));
                
                world.setDynamicProperty("player_nation_" + player.name, nId);

                const equipment = player.getComponent("equippable");
                if (equipment) {
                    const mainhand = equipment.getEquipment("Mainhand");
                    if (mainhand && mainhand.amount > 1) {
                        mainhand.amount--;
                        equipment.setEquipment("Mainhand", mainhand);
                    } else {
                        equipment.setEquipment("Mainhand", undefined);
                    }
                }
            });
        }
    } else if (item.typeId === "nf:check_card") {
        event.cancel = true;
        system.run(() => {
            const nId = getNationId(player);
            if (!nId) { player.sendMessage("§c국가에 소속되어야 조회 가능합니다."); return; }
            const curr = getCurrencyInfo(nId);
            let money = 0;
            try { money = world.scoreboard.getObjective("player_money").getScore(player); } catch(e) {}
            player.sendMessage(`§a[체크카드] 잔액: ${money.toLocaleString()} ${curr.symbol}`);
        });
    } else if (item.typeId === "nf:credit_card") {
        event.cancel = true;
        system.run(() => {
            const nId = getNationId(player);
            if (!nId) { player.sendMessage("§c국가에 소속되어야 조회 가능합니다."); return; }
            const curr = getCurrencyInfo(nId);
            let creditScore = JSON.parse(world.getDynamicProperty("credit_score_" + player.name) || "500");
            let debt = JSON.parse(world.getDynamicProperty("debt_" + player.name) || "0");
            let limit = creditScore * 100;
            player.sendMessage(`§6[신용카드] 총 한도: ${Math.floor(limit).toLocaleString()} ${curr.symbol} | 누적 사용액(빚): ${Math.floor(debt).toLocaleString()} ${curr.symbol}`);
        });
    } else if (item.typeId === "nf:property_wand") {
        event.cancel = true;
        system.run(() => {
            const x1 = JSON.parse(world.getDynamicProperty("re_pos1_x_" + player.name) || "null");
            const y1 = JSON.parse(world.getDynamicProperty("re_pos1_y_" + player.name) || "null");
            const z1 = JSON.parse(world.getDynamicProperty("re_pos1_z_" + player.name) || "null");
            const x2 = JSON.parse(world.getDynamicProperty("re_pos2_x_" + player.name) || "null");
            const y2 = JSON.parse(world.getDynamicProperty("re_pos2_y_" + player.name) || "null");
            const z2 = JSON.parse(world.getDynamicProperty("re_pos2_z_" + player.name) || "null");
            
            if (x1 === null || x2 === null) {
                player.sendMessage("§c[부동산] 영역이 완전히 설정되지 않았습니다. 지팡이로 두 블록을 클릭(하나는 웅크리고)하세요.");
                return;
            }
            
            new ModalFormData().title("§l부동산 및 상업 건물 매물 등록")
            .dropdown("용도 및 거래 방식 선택", [
                "🏠 주택 매매 등록 (단독 소유권 판매)",
                "🏠 주택 월세 임대 등록 (세입자 임대)",
                "🏢 상업용 건물 통째로 매매 (소유권 판매)",
                "🏢 상업용 건물주 직접 등록 (방 임대업 시작)"
            ])
            .textField("매물/건물 이름", "예: 강남빌라 101호")
            .textField("가격 / 월세 (단위: ₩)", "예: 50000")
            .show(player).then(res => {
                if (res.canceled) return;
                const type = res.formValues[0];
                const name = res.formValues[1] || "이름 없는 매물";
                const price = parseInt(res.formValues[2]);
                if (isNaN(price) || price < 0) { player.sendMessage("§c가격을 올바르게 입력하세요."); return; }
                
                const minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
                const minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
                const minZ = Math.min(z1, z2), maxZ = Math.max(z1, z2);
                
                const reData = {
                    id: "re_" + Date.now(),
                    type: type, name: name, price: price, owner: player.name, tenant: "", rooms: [],
                    min: {x: minX, y: minY, z: minZ}, max: {x: maxX, y: maxY, z: maxZ},
                    dimension: player.dimension.id
                };
                
                let estates = JSON.parse(world.getDynamicProperty("real_estates") || "[]");
                estates.push(reData);
                world.setDynamicProperty("real_estates", JSON.stringify(estates));
                
                const signX = Math.floor((minX + maxX)/2);
                const signY = Math.floor((minY + maxY)/2);
                const signZ = Math.floor((minZ + maxZ)/2);
                
                if (type === 0) {
                    const sign = player.dimension.spawnEntity("nf:property_sign", {x: signX + 0.5, y: signY + 0.5, z: signZ + 0.5});
                    sign.nameTag = "§b[주택 매매]\n§f" + name + "\n§e매매가: " + price.toLocaleString() + "₩\n§a클릭하여 인수";
                    sign.setDynamicProperty("re_id", reData.id);
                    player.sendMessage("§a[부동산] 주택 매매 등록 완료! (" + minX + "," + minY + "," + minZ + " ~ " + maxX + "," + maxY + "," + maxZ + ")");
                } else if (type === 1) {
                    const sign = player.dimension.spawnEntity("nf:property_sign", {x: signX + 0.5, y: signY + 0.5, z: signZ + 0.5});
                    sign.nameTag = "§a[주택 임대]\n§f" + name + "\n§e월세: " + price.toLocaleString() + "₩\n§7(48분마다)\n§b클릭하여 입주";
                    sign.setDynamicProperty("re_id", reData.id);
                    player.sendMessage("§a[부동산] 주택 월세 임대 등록 완료! (" + minX + "," + minY + "," + minZ + " ~ " + maxX + "," + maxY + "," + maxZ + ")");
                } else if (type === 2) {
                    const sign = player.dimension.spawnEntity("nf:property_sign", {x: signX + 0.5, y: signY + 0.5, z: signZ + 0.5});
                    sign.nameTag = "§6[건물 매매]\n§f" + name + "\n§e매매가: " + price.toLocaleString() + "₩\n§a클릭하여 건물주 되기";
                    sign.setDynamicProperty("re_id", reData.id);
                    player.sendMessage("§a[부동산] 상업용 건물 매매 등록 완료! (" + minX + "," + minY + "," + minZ + " ~ " + maxX + "," + maxY + "," + maxZ + ")");
                } else if (type === 3) {
                    player.runCommand("give @s nf:building_cert 1");
                    player.sendMessage("§a[건물주 등록] '" + name + "' 건물의 소유 증명서가 발급되었습니다! 증명서를 들고 허공을 클릭하여 임대할 방들을 관리하세요.");
                }
            });
        });
    } else if (item.typeId === "nf:id_card") {
        event.cancel = true;
        system.run(() => { showIdCardUI(player); });
    } else if (item.typeId === "nf:building_cert") {
        event.cancel = true;
        system.run(() => {
            let estates = JSON.parse(world.getDynamicProperty("real_estates") || "[]");
            const myBuildings = estates.filter(e => e.owner === player.name && (e.type === 2 || e.type === 3));
            if (myBuildings.length === 0) { player.sendMessage("§c소유 중인 상업용 건물이 없습니다."); return; }
            
            if (myBuildings.length === 1) { showBuildingManageUI(player, myBuildings[0]); return; }
            
            const form = new ActionFormData().title("§l소유 건물 목록").body("관리할 건물을 선택하세요.");
            for (const b of myBuildings) form.button(`§e🏢 ${b.name}`);
            form.button("닫기");
            form.show(player).then(res => {
                if (res.canceled || res.selection === myBuildings.length) return;
                showBuildingManageUI(player, myBuildings[res.selection]);
            });
        });
    } else if (item.typeId === "nf:guide_book") {
        event.cancel = true;
        system.run(() => { showGuideBookUI(player); });
    }
});

function showBuildingManageUI(player, building) {
    const form = new ActionFormData().title(`§l건물 관리 - ${building.name}`)
    .body(`§e건물주: §f${building.owner}\n§b현재 등록된 임대 방(점포) 수: §f${(building.rooms || []).length}개\n\n원하시는 작업을 선택하세요.`);
    
    form.button("§a+ 신규 임대 방(점포) 등록하기");
    const rooms = building.rooms || [];
    for (const r of rooms) {
        form.button(`§e방 ${r.name}\n§f월세: ${r.price.toLocaleString()}₩ | ${r.tenant ? "세입자: " + r.tenant : "§b임대 문의중"}`);
    }
    form.button("닫기");
    
    form.show(player).then(res => {
        if (res.canceled || res.selection === rooms.length + 1) return;
        if (res.selection === 0) {
            const loc = player.location;
            new ModalFormData().title(`§l신규 임대 방 등록 (${building.name})`)
            .textField("방/점포 이름 (호수)", "예: 101호")
            .textField("월세 금액 (₩)", "예: 30000")
            .show(player).then(r => {
                if (r.canceled) return;
                const roomName = r.formValues[0];
                const roomPrice = parseInt(r.formValues[1]);
                if (!roomName || roomName === "" || isNaN(roomPrice) || roomPrice < 0) {
                    player.sendMessage("§c입력값이 올바르지 않습니다."); return;
                }
                
                let estates = JSON.parse(world.getDynamicProperty("real_estates") || "[]");
                let bIdx = estates.findIndex(e => e.id === building.id);
                if (bIdx === -1) return;
                
                const roomId = "room_" + Date.now();
                if (!estates[bIdx].rooms) estates[bIdx].rooms = [];
                estates[bIdx].rooms.push({ id: roomId, name: roomName, price: roomPrice, tenant: "", loc: { x: Math.floor(loc.x), y: Math.floor(loc.y), z: Math.floor(loc.z) } });
                world.setDynamicProperty("real_estates", JSON.stringify(estates));
                
                const sign = player.dimension.spawnEntity("nf:property_sign", {x: Math.floor(loc.x) + 0.5, y: Math.floor(loc.y) + 0.5, z: Math.floor(loc.z) + 0.5});
                sign.nameTag = `§b[임대 문의]\n§f${building.name} ${roomName}\n§e월세: ${roomPrice.toLocaleString()}₩\n§a클릭하여 점포 임대`;
                sign.setDynamicProperty("re_id", building.id);
                sign.setDynamicProperty("room_id", roomId);
                
                player.sendMessage(`§a[건물 관리] 성공적으로 '${roomName}' 점포 임대 문의가 등록되었습니다! (현재 서 있는 위치에 표지판 생성됨)`);
            });
        } else {
            const r = rooms[res.selection - 1];
            new ActionFormData().title(`§l방 관리 - ${r.name}`).body(`§e방 이름: §f${r.name}\n§a월세: §f${r.price.toLocaleString()}₩\n§b세입자: §f${r.tenant ? r.tenant : "없음 (임대 대기중)"}`)
            .button(r.tenant ? "§c세입자 퇴거 (계약 해지)" : "§7(세입자 없음)")
            .button("뒤로 가기")
            .show(player).then(r2 => {
                if (r2.canceled || r2.selection === 1) { showBuildingManageUI(player, building); return; }
                if (r2.selection === 0 && r.tenant) {
                    let estates = JSON.parse(world.getDynamicProperty("real_estates") || "[]");
                    let bIdx = estates.findIndex(e => e.id === building.id);
                    if (bIdx !== -1) {
                        let rIdx = estates[bIdx].rooms.findIndex(rm => rm.id === r.id);
                        if (rIdx !== -1) {
                            const oldTenant = estates[bIdx].rooms[rIdx].tenant;
                            estates[bIdx].rooms[rIdx].tenant = "";
                            world.setDynamicProperty("real_estates", JSON.stringify(estates));
                            player.sendMessage(`§c[건물 관리] 세입자(${oldTenant})와의 임대 계약을 해지했습니다.`);
                            
                            const loc = estates[bIdx].rooms[rIdx].loc;
                            const signs = player.dimension.getEntities({ type: "nf:property_sign", location: { x: loc.x + 0.5, y: loc.y + 0.5, z: loc.z + 0.5 }, maxDistance: 1.0 });
                            for (const s of signs) {
                                s.nameTag = `§b[임대 문의]\n§f${building.name} ${r.name}\n§e월세: ${r.price.toLocaleString()}₩\n§a클릭하여 점포 임대`;
                            }
                        }
                    }
                }
            });
        }
    });
}

function getNationId(playerOrName) {
    if (typeof playerOrName === "string") {
        return world.getDynamicProperty("player_nation_" + playerOrName) || null;
    } else {
        const tags = playerOrName.getTags();
        for (const tag of tags) if (tag.startsWith("nation_id_")) return tag;
        return null;
    }
}

function getCurrencyInfo(nId) {
    if (!nId) return { symbol: "무국적", supply: 1, rate: 1.0, tax_rate: 50 };
    let currencies = JSON.parse(world.getDynamicProperty("currencies") || "{}");
    return currencies[nId] || { symbol: "COIN", supply: 100000, rate: 1.0, tax_rate: 50 };
}

// ====== 부동산 표지판 클릭 (매수 및 임대 계약) ======
world.beforeEvents.playerInteractWithEntity.subscribe((event) => {
    const target = event.target;
    const player = event.player;
    
    if (target.typeId === "nf:realtor_npc") {
        event.cancel = true;
        system.run(() => { showRealtorMenu(player); });
        return;
    }
    
    if (target.typeId !== "nf:property_sign") return;
    event.cancel = true;
    
    system.run(() => {
        const reId = target.getDynamicProperty("re_id");
        if (!reId) return;
        let estates = JSON.parse(world.getDynamicProperty("real_estates") || "[]");
        let bIdx = estates.findIndex(e => e.id === reId);
        if (bIdx === -1) {
            target.remove();
            player.sendMessage("§c[부동산] 존재하지 않는 매물 표지판을 철거했습니다.");
            return;
        }
        let estate = estates[bIdx];
        const roomId = target.getDynamicProperty("room_id");
        
        if (roomId) {
            let rIdx = (estate.rooms || []).findIndex(rm => rm.id === roomId);
            if (rIdx === -1) { target.remove(); return; }
            let room = estate.rooms[rIdx];
            
            if (room.tenant === player.name) {
                player.sendMessage(`§e[부동산] 당신이 임대 중인 점포입니다. (월세: ${room.price.toLocaleString()}₩)`); return;
            }
            if (room.tenant !== "") {
                player.sendMessage(`§c[부동산] 이미 임대된 점포입니다. (세입자: ${room.tenant})`); return;
            }
            if (estate.owner === player.name) {
                new ActionFormData().title(`§l내 점포 관리 - ${room.name}`).body(`§e월세: ${room.price.toLocaleString()}₩ | 임대 문의중\n이 임대 문의 표지판을 철거하시겠습니까?`)
                .button("§c임대 문의 철거").button("닫기").show(player).then(r => {
                    if (r.canceled || r.selection === 1) return;
                    estates[bIdx].rooms.splice(rIdx, 1);
                    world.setDynamicProperty("real_estates", JSON.stringify(estates));
                    target.remove();
                    player.sendMessage("§c[건물 관리] 임대 문의 표지판을 철거했습니다.");
                });
                return;
            }
            
            player.sendMessage("§c[부동산 안내] 매물 구매 및 점포 임대 계약은 도시의 '부동산 중개인 NPC'를 찾아가 상호작용해 주세요.");
            return;
        }
        
        if (estate.type === 0 && estate.is_sold) {
            player.sendMessage("§c[부동산] 이미 매매가 완료된 주택입니다.");
            target.remove();
            return;
        }
        if (estate.type === 1) {
            if (estate.tenant === player.name) { player.sendMessage(`§e[부동산] 당신이 임대 중인 주택입니다. (월세: ${estate.price.toLocaleString()}₩)`); return; }
            if (estate.tenant !== "") { player.sendMessage(`§c[부동산] 이미 임대된 주택입니다. (세입자: ${estate.tenant})`); return; }
        }
        
        if (estate.owner === player.name) {
            new ActionFormData().title(`§l내 매물 관리 - ${estate.name}`).body(`§e등록 가격/월세: ${estate.price.toLocaleString()}₩\n이 매물 등록을 취소하고 표지판을 철거하시겠습니까?`)
            .button("§c매물 등록 취소 및 철거").button("닫기").show(player).then(r => {
                if (r.canceled || r.selection === 1) return;
                estates.splice(bIdx, 1);
                world.setDynamicProperty("real_estates", JSON.stringify(estates));
                target.remove();
                player.sendMessage("§c[부동산] 매물 등록을 취소했습니다.");
            });
            return;
        }

        player.sendMessage("§c[부동산 안내] 매물 구매 및 임대 계약은 도시의 '부동산 중개인 NPC'를 찾아가 상호작용해 주세요.");
    });
});

// ====== 부동산 중개인 NPC 시스템 ======
function showRealtorMenu(player) {
    new ActionFormData().title("§l🏢 부동산 중개소")
    .body("§e환영합니다! 도시의 다양한 부동산 매물 및 임대 정보를 한눈에 확인하고 간편하게 계약하실 수 있습니다.\n\n§b원하시는 거래 종류를 선택하세요.")
    .button("§a🏠 주택 매매 목록 (소유권 분양)")
    .button("§b🏠 주택 월세 목록 (단독주택 임대)")
    .button("§6🏢 상업용 건물 매매 (건물주 되기)")
    .button("§d🏬 상가 점포 월세 목록 (방 임대)")
    .button("닫기")
    .show(player).then(res => {
        if (res.canceled || res.selection === 4) return;
        showRealtorList(player, res.selection);
    });
}

function showRealtorList(player, categoryType) {
    let estates = JSON.parse(world.getDynamicProperty("real_estates") || "[]");
    let list = [];
    let title = "";
    let isRoom = (categoryType === 3);

    if (categoryType === 0) {
        title = "§l🏠 주택 매매 목록";
        list = estates.filter(e => e.type === 0 && !e.is_sold);
    } else if (categoryType === 1) {
        title = "§l🏠 주택 월세 목록";
        list = estates.filter(e => e.type === 1 && e.tenant === "");
    } else if (categoryType === 2) {
        title = "§l🏢 상업용 건물 매매";
        list = estates.filter(e => e.type === 2);
    } else if (categoryType === 3) {
        title = "§l🏬 상가 점포 월세 목록";
        for (const e of estates) {
            if (e.rooms) {
                for (const r of e.rooms) {
                    if (r.tenant === "") {
                        list.push({ estate: e, room: r });
                    }
                }
            }
        }
    }

    if (list.length === 0) {
        new ActionFormData().title(title).body("§c현재 등록된 매물이 없습니다.").button("뒤로 가기").show(player).then(r => {
            if (!r.canceled) showRealtorMenu(player);
        });
        return;
    }

    const form = new ActionFormData().title(title).body("§e상세 정보 및 계약을 진행할 매물을 선택하세요.");
    for (const item of list) {
        if (isRoom) {
            form.button(`§d🏬 ${item.estate.name} ${item.room.name}\n§f월세: ${item.room.price.toLocaleString()}₩ | 건물주: ${item.estate.owner}`);
        } else {
            let priceStr = categoryType === 1 ? `월세: ${item.price.toLocaleString()}₩` : `매매가: ${item.price.toLocaleString()}₩`;
            form.button(`§e🏠 ${item.name}\n§f${priceStr} | 소유자: ${item.owner}`);
        }
    }
    form.button("뒤로 가기");

    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === list.length) { showRealtorMenu(player); return; }
        
        if (isRoom) {
            showRealtorTradeUI(player, list[res.selection].estate, list[res.selection].room);
        } else {
            showRealtorTradeUI(player, list[res.selection], null);
        }
    });
}

function showRealtorTradeUI(player, estate, room) {
    let money = 0; try { money = world.scoreboard.getObjective("player_money").getScore(player); } catch(e){}
    let estates = JSON.parse(world.getDynamicProperty("real_estates") || "[]");
    let bIdx = estates.findIndex(e => e.id === estate.id);
    if (bIdx === -1) { player.sendMessage("§c[부동산] 존재하지 않는 매물입니다."); return; }

    if (room) {
        let rIdx = (estates[bIdx].rooms || []).findIndex(rm => rm.id === room.id);
        if (rIdx === -1) { player.sendMessage("§c[부동산] 존재하지 않는 점포입니다."); return; }
        
        new ActionFormData().title("§l점포 임대 계약")
        .body(`§e🏢 건물명: §f${estate.name} ${room.name}\n§a💰 월세: §f${room.price.toLocaleString()}₩ (48분마다)\n§b👑 건물주: §f${estate.owner}\n\n§d[계약 혜택] 계약 체결 시 영업용 POS 단말기 1대가 즉시 지급됩니다!\n계약하시겠습니까?`)
        .button("§a계약 체결 및 첫 달 월세 결제").button("취소").show(player).then(r => {
            if (r.canceled || r.selection === 1) return;
            if (money < room.price) { player.sendMessage("§c잔액이 부족합니다."); return; }
            
            player.runCommand(`scoreboard players remove @s player_money ${room.price}`);
            player.dimension.runCommand(`scoreboard players add "${estate.owner}" player_money ${room.price}`);
            try { player.dimension.runCommand(`tellraw "${estate.owner}" {"rawtext":[{"text":"§a[부동산 입금] ${player.name}님이 점포(${estate.name} ${room.name}) 임대 계약을 체결하여 첫 달 월세 ${room.price.toLocaleString()}₩이 입금되었습니다!"}]}`); } catch(e){}
            
            estates[bIdx].rooms[rIdx].tenant = player.name;
            world.setDynamicProperty("real_estates", JSON.stringify(estates));
            
            const allSigns = player.dimension.getEntities({ type: "nf:property_sign" });
            for (const s of allSigns) {
                if (s.getDynamicProperty("re_id") === estate.id && s.getDynamicProperty("room_id") === room.id) {
                    s.nameTag = `§d[영업중]\n§f${estate.name} ${room.name}\n§7대표: ${player.name}\n§e월세: ${room.price.toLocaleString()}₩`;
                }
            }
            
            player.runCommand("give @s nf:pos_terminal 1");
            player.sendMessage("§a[점포 임대] 계약이 체결되었습니다! 인벤토리로 POS 단말기가 지급되었습니다. 점포에 설치하여 장사를 시작하세요!");
        });
        return;
    }

    if (estate.type === 0) {
        new ActionFormData().title("§l주택 매매 계약").body(`§e🏠 주택명: §f${estate.name}\n§a💰 매매가: §f${estate.price.toLocaleString()}₩\n§b👑 소유자: §f${estate.owner}\n\n구매하시겠습니까?`)
        .button("§a매매 체결 (구매)").button("취소").show(player).then(r => {
            if (r.canceled || r.selection === 1) return;
            if (money < estate.price) { player.sendMessage("§c잔액이 부족합니다."); return; }
            player.runCommand(`scoreboard players remove @s player_money ${estate.price}`);
            player.dimension.runCommand(`scoreboard players add "${estate.owner}" player_money ${estate.price}`);
            try { player.dimension.runCommand(`tellraw "${estate.owner}" {"rawtext":[{"text":"§a[부동산 입금] ${player.name}님이 주택(${estate.name})을 매수하여 ${estate.price.toLocaleString()}₩이 입금되었습니다!"}]}`); } catch(e){}
            
            estates[bIdx].owner = player.name;
            estates[bIdx].is_sold = true;
            world.setDynamicProperty("real_estates", JSON.stringify(estates));
            
            const allSigns = player.dimension.getEntities({ type: "nf:property_sign" });
            for (const s of allSigns) {
                if (s.getDynamicProperty("re_id") === estate.id) s.remove();
            }
            player.sendMessage("§a[부동산] 주택 매매 완료! 이제 이 주택은 당신의 소유입니다.");
        });
    } else if (estate.type === 1) {
        new ActionFormData().title("§l주택 임대 계약").body(`§e🏠 주택명: §f${estate.name}\n§a💰 월세: §f${estate.price.toLocaleString()}₩ (48분마다)\n§b👑 집주인: §f${estate.owner}\n\n계약하시겠습니까?`)
        .button("§a임대 계약 및 첫 달 월세 결제").button("취소").show(player).then(r => {
            if (r.canceled || r.selection === 1) return;
            if (money < estate.price) { player.sendMessage("§c잔액이 부족합니다."); return; }
            player.runCommand(`scoreboard players remove @s player_money ${estate.price}`);
            player.dimension.runCommand(`scoreboard players add "${estate.owner}" player_money ${estate.price}`);
            try { player.dimension.runCommand(`tellraw "${estate.owner}" {"rawtext":[{"text":"§a[부동산 입금] ${player.name}님이 주택(${estate.name}) 임대 계약을 체결하여 첫 달 월세 ${estate.price.toLocaleString()}₩이 입금되었습니다!"}]}`); } catch(e){}
            
            estates[bIdx].tenant = player.name;
            world.setDynamicProperty("real_estates", JSON.stringify(estates));
            
            const allSigns = player.dimension.getEntities({ type: "nf:property_sign" });
            for (const s of allSigns) {
                if (s.getDynamicProperty("re_id") === estate.id) {
                    s.nameTag = `§d[임대중]\n§f${estate.name}\n§7세입자: ${player.name}\n§e월세: ${estate.price.toLocaleString()}₩`;
                }
            }
            player.sendMessage("§a[부동산] 주택 임대 계약 완료! 48분마다 월세가 자동 출금됩니다.");
        });
    } else if (estate.type === 2) {
        new ActionFormData().title("§l상업용 건물 매매 계약").body(`§e🏢 건물명: §f${estate.name}\n§a💰 매매가: §f${estate.price.toLocaleString()}₩\n§b👑 건물주: §f${estate.owner}\n\n건물을 인수하시겠습니까?`)
        .button("§a건물 인수 및 대금 결제").button("취소").show(player).then(r => {
            if (r.canceled || r.selection === 1) return;
            if (money < estate.price) { player.sendMessage("§c잔액이 부족합니다."); return; }
            player.runCommand(`scoreboard players remove @s player_money ${estate.price}`);
            player.dimension.runCommand(`scoreboard players add "${estate.owner}" player_money ${estate.price}`);
            try { player.dimension.runCommand(`tellraw "${estate.owner}" {"rawtext":[{"text":"§a[부동산 입금] ${player.name}님이 건물(${estate.name})을 인수하여 ${estate.price.toLocaleString()}₩이 입금되었습니다!"}]}`); } catch(e){}
            
            estates[bIdx].owner = player.name;
            estates[bIdx].type = 3;
            world.setDynamicProperty("real_estates", JSON.stringify(estates));
            
            const allSigns = player.dimension.getEntities({ type: "nf:property_sign" });
            for (const s of allSigns) {
                if (s.getDynamicProperty("re_id") === estate.id) s.remove();
            }
            player.runCommand("give @s nf:building_cert 1");
            player.sendMessage("§a[부동산] 상업용 건물 인수 완료! 건물 소유 증명서를 발급받았습니다. 증명서를 들고 클릭하여 방 임대를 시작하세요.");
        });
    }
}


// ====== 현수막 및 POS 기기 설치/파괴 로직 ======
world.afterEvents.playerPlaceBlock.subscribe((event) => {
    const block = event.block;
    const player = event.player;
    if (block.typeId === "nf:pos_terminal") {
        const marker = event.dimension.spawnEntity("nf:pos_marker", { x: block.location.x + 0.5, y: block.location.y, z: block.location.z + 0.5 });
        marker.setDynamicProperty("pos_owner", ""); marker.nameTag = "§8주인 없는 단말기";
    }
    
    if (block.typeId.includes("banner")) {
        const nId = getNationId(player);
        if (!nId) {
            system.run(() => { player.sendMessage("§c[영토] 국가에 소속된 국민/지도자만 현수막을 설치하여 영토를 점령/확장할 수 있습니다."); }); return;
        }
        system.run(() => {
            let allFlagpoles = JSON.parse(world.getDynamicProperty("all_flagpoles") || "{}");
            let nationNames = JSON.parse(world.getDynamicProperty("nation_names") || "{}");
            const nationName = nationNames[nId] || nId.replace("nation_id_", "국가 ");
            const loc = block.location; const key = `${loc.x},${loc.y},${loc.z}`;
            allFlagpoles[key] = nId;
            world.setDynamicProperty("all_flagpoles", JSON.stringify(allFlagpoles));
            recalculateBorders(allFlagpoles);
            player.sendMessage(`§a[영토 점령] 현수막이 설치되어 '${nationName}' 국가의 영토로 편입되었습니다! (${loc.x}, ${loc.y}, ${loc.z})`);
        });
    }
});

world.afterEvents.playerBreakBlock.subscribe((event) => {
    const perm = event.brokenBlockPermutation;
    const loc = event.block.location;
    if (perm.type.id === "nf:pos_terminal") {
        const markers = event.dimension.getEntities({ type: "nf:pos_marker", location: { x: loc.x + 0.5, y: loc.y, z: loc.z + 0.5 }, maxDistance: 0.5 });
        for (const marker of markers) marker.remove();
    }
    
    if (perm.type.id.includes("banner")) {
        system.run(() => {
            let allFlagpoles = JSON.parse(world.getDynamicProperty("all_flagpoles") || "{}");
            const key = `${loc.x},${loc.y},${loc.z}`;
            if (allFlagpoles[key]) {
                delete allFlagpoles[key];
                world.setDynamicProperty("all_flagpoles", JSON.stringify(allFlagpoles));
                recalculateBorders(allFlagpoles);
            }
        });
    }
});

// ====== 블록 상호작용 (POS, 무역포트, 지팡이) ======
world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    const block = event.block;
    const player = event.player;
    
    const now = Date.now();
    const lastTime = JSON.parse(world.getDynamicProperty("last_interact_time_" + player.name) || "0");
    if (now - lastTime < 500) return;
    world.setDynamicProperty("last_interact_time_" + player.name, JSON.stringify(now));
    
    if (event.itemStack && event.itemStack.typeId === "nf:property_wand") {
        event.cancel = true;
        const isSneaking = player.isSneaking;
        const pos = block.location;
        if (isSneaking) {
            world.setDynamicProperty("re_pos2_x_" + player.name, JSON.stringify(pos.x));
            world.setDynamicProperty("re_pos2_y_" + player.name, JSON.stringify(pos.y));
            world.setDynamicProperty("re_pos2_z_" + player.name, JSON.stringify(pos.z));
            system.run(() => { player.sendMessage("§a[부동산] 두 번째 지점 (Pos2) 설정: " + pos.x + ", " + pos.y + ", " + pos.z); });
        } else {
            world.setDynamicProperty("re_pos1_x_" + player.name, JSON.stringify(pos.x));
            world.setDynamicProperty("re_pos1_y_" + player.name, JSON.stringify(pos.y));
            world.setDynamicProperty("re_pos1_z_" + player.name, JSON.stringify(pos.z));
            system.run(() => { player.sendMessage("§a[부동산] 첫 번째 지점 (Pos1) 설정: " + pos.x + ", " + pos.y + ", " + pos.z + "\n(웅크리고 클릭하면 Pos2가 설정됩니다)"); });
        }
        return;
    }

    if (block.typeId === "nf:pos_terminal") {
        event.cancel = true;
        system.run(() => {
            const markers = player.dimension.getEntities({ type: "nf:pos_marker", location: { x: block.location.x + 0.5, y: block.location.y, z: block.location.z + 0.5 }, maxDistance: 0.5 });
            if (markers.length === 0) return;
            const marker = markers[0];
            checkAndProcessPendingSupplies(player.dimension, marker); // 자동 적재 트리거
            const owner = marker.getDynamicProperty("pos_owner") || "";
            const activeCartStr = marker.getDynamicProperty("pos_active_cart") || "";
            
            const equip = player.getComponent("equippable");
            const mainhand = equip ? equip.getEquipment("Mainhand") : undefined;
            
            if (mainhand && mainhand.typeId === "nf:kiosk_linker") {
                if (owner !== player.name) { player.sendMessage("§c[연결막대기] 본인의 계산대만 연동할 수 있습니다."); return; }
                const posData = JSON.stringify({ x: block.location.x, y: block.location.y, z: block.location.z, dim: player.dimension.id });
                player.setDynamicProperty("kiosk_linker_pos", posData);
                player.sendMessage("§a[키오스크 연결] 계산대 위치가 저장되었습니다. 이제 연동할 키오스크(nf:kiosk)를 터치하세요!");
                return;
            }
            
            if (mainhand && mainhand.typeId === "nf:box_linker") {
                if (owner !== player.name) { player.sendMessage("§c[상자 연결] 본인의 계산대만 연동할 수 있습니다."); return; }
                const posData = JSON.stringify({ x: block.location.x, y: block.location.y, z: block.location.z, dim: player.dimension.id });
                player.setDynamicProperty("box_linker_pos", posData);
                player.sendMessage("§a[상자 연결] 계산대 위치가 저장되었습니다.\n§7이제 연동할 바닐라 일반 상자(Chest)를 터치하여 용도를 선택하세요!");
                return;
            }
            
            if (owner === "") {
                new ActionFormData().title("§lPOS 단말기").body("아직 주인이 없습니다.")
                .button("§a점주 등록하기")
                .show(player).then(res => {
                    if (res.canceled) return;
                    marker.setDynamicProperty("pos_owner", player.name);
                    marker.setDynamicProperty("pos_catalog", "[]");
                    marker.setDynamicProperty("pos_cart", "[]");
                    marker.setDynamicProperty("pos_active_cart", "");
                    marker.nameTag = "§e" + player.name + "의 상점";
                    player.sendMessage("§a[POS] 이제 당신이 점주입니다.");
                });
                return;
            }

            if (activeCartStr !== "") {
                const isCard = mainhand && (mainhand.typeId === "nf:check_card" || mainhand.typeId === "nf:credit_card");
                if (isCard) {
                    processPosPayment(player, marker, owner, JSON.parse(activeCartStr));
                } else {
                    if (player.name === owner) {
                        new ActionFormData().title("§l결제 대기 관리").body("현재 결제 대기 중인 장바구니 목록이 있습니다.\n결제 대기 상태를 취소하시겠습니까?")
                        .button("§c결제 대기 취소")
                        .button("§a닫기 (유지)")
                        .show(player).then(res => {
                            if (res.canceled || res.selection === 1) return;
                            marker.setDynamicProperty("pos_active_cart", "");
                            marker.nameTag = "§e" + owner + "의 상점";
                            player.sendMessage("§a[POS] 결제 대기 상태가 취소되었습니다.");
                        });
                    } else {
                        player.sendMessage("§c[POS] 결제 대기 중입니다. 손에 카드(체크/신용카드)를 들고 터치해 주세요.");
                    }
                }
                return;
            }

            if (player.name === owner) {
                if (mainhand && !mainhand.typeId.includes("nf:") && !mainhand.typeId.includes("minecraft:stick")) {
                    const itemName = mainhand.typeId;
                    const displayItemName = itemName.replace("minecraft:", "");
                    new ModalFormData().title("§l단축 상품 등록").textField(`상품명: ${displayItemName}\n판매 가격을 입력하세요 (₩)`, "예: 5000")
                    .show(player).then(r => {
                        if (r.canceled) return; let price = parseInt(r.formValues[0]); if(isNaN(price) || price < 0) return;
                        let catalog = JSON.parse(marker.getDynamicProperty("pos_catalog") || "[]");
                        let idx = catalog.findIndex(c => c.item === itemName);
                        if (idx !== -1) catalog[idx].price = price;
                        else catalog.push({ item: itemName, name: displayItemName, price: price });
                        marker.setDynamicProperty("pos_catalog", JSON.stringify(catalog));
                        player.sendMessage(`§a[상품 등록] 성공적으로 '${displayItemName}' 상품이 ${price.toLocaleString()}₩에 등록되었습니다!`);
                    });
                    return;
                }

                const hasSupplier = marker.getDynamicProperty("supplierId") !== undefined && marker.getDynamicProperty("supplierId") !== "";
                const hasFranchise = marker.getDynamicProperty("franchisedSupplier") !== undefined && marker.getDynamicProperty("franchisedSupplier") !== "";
                
                const form = new ActionFormData().title("§lPOS 점주 메뉴").body("원하시는 작업을 선택하세요.")
                .button("§a🛒 계산 시작 (장바구니 담기)")
                .button("§b📦 판매 상품 관리 (영구 등록/삭제)")
                .button("§6📈 기업 주식 상장 (IPO 신청)")
                .button("§d🏢 점주 사업자 등록 (상점 상자 발급)")
                .button("§e🚚 납품업체 등록 (납품 상자 발급)")
                .button("§9🤝 납품업체 가맹 계약 (물류 연결)")
                .button("§3🏷️ 가게 이름 변경");
                
                if (hasFranchise) form.button("§5📝 상품 발주 시스템 (재고 주문)");
                if (hasSupplier) {
                    form.button("§2📦 납품 처리 (가맹점 배송 완료)");
                    form.button("§e🚚 납품업체 도매 카탈로그 관리");
                }
                form.button("§b📥 내 인벤토리에서 계산대로 아이템 채우기");
                form.button("§d📤 계산대 인벤토리 아이템 회수하기");
                form.button("§c⚠️ 점주 등록 해제 (초기화)");
                
                let actions = [
                    () => showPosSellUI(player, marker),
                    () => showPosCatalogUI(player, marker),
                    () => showPosIPOUI(player, marker),
                    () => showPosBusinessRegisterUI(player, marker),
                    () => showPosSupplierRegisterUI(player, marker),
                    () => showPosFranchiseUI(player, marker),
                    () => {
                        let curName = marker.nameTag.replace("§e", "");
                        new ModalFormData().title("§l가게 이름 변경")
                        .textField("새로운 가게 이름을 입력하세요.", "예: 스타벅스 1호점", curName)
                        .show(player).then(r => {
                            if (r.canceled) return;
                            let newName = r.formValues[0].trim();
                            if (!newName) return;
                            marker.nameTag = "§e" + newName;
                            player.sendMessage(`§a[가게 이름 변경] 성공적으로 가게 이름을 '§e${newName}§a'(으)로 변경했습니다!`);
                        });
                    }
                ];
                if (hasFranchise) actions.push(() => showPosOrderUI(player, marker));
                if (hasSupplier) {
                    actions.push(() => showPosSupplyProcessUI(player, marker));
                    actions.push(() => showSupplierCatalogUI(player, marker));
                }
                actions.push(() => showPosFillUI(player, marker));
                actions.push(() => showPosWithdrawUI(player, marker));
                actions.push(() => {
                    marker.setDynamicProperty("pos_owner", "");
                    marker.setDynamicProperty("pos_catalog", "[]"); marker.setDynamicProperty("pos_cart", "[]"); marker.setDynamicProperty("pos_active_cart", "");
                    marker.nameTag = "§8주인 없는 단말기"; player.sendMessage("§a[POS] 단말기가 초기화되었습니다.");
                });
                
                form.show(player).then(res => {
                    if(res.canceled) return;
                    actions[res.selection]();
                });
            } else {
                player.sendMessage("§c[POS] 현재 판매 대기 중인 상품이 없습니다. (키오스크를 이용해 주세요)");
            }
        });
    } else if (block.typeId === "nf:kiosk") {
        event.cancel = true;
        system.run(() => {
            const loc = block.location;
            const kioskKey = `${loc.x}_${loc.y}_${loc.z}_${player.dimension.id}`;
            const equip = player.getComponent("equippable");
            const mainhand = equip ? equip.getEquipment("Mainhand") : undefined;
            
            if (mainhand && mainhand.typeId === "nf:kiosk_linker") {
                let linkerPosStr = player.getDynamicProperty("kiosk_linker_pos");
                if (!linkerPosStr) { player.sendMessage("§c[키오스크 연동] 먼저 계산대(nf:pos_terminal)를 터치하여 위치를 저장해 주세요."); return; }
                let linkerPos = JSON.parse(linkerPosStr);
                if (linkerPos.dim !== player.dimension.id) { player.sendMessage("§c[키오스크 연동] 같은 차원의 계산대만 연동 가능합니다."); return; }
                
                const markers = player.dimension.getEntities({ type: "nf:pos_marker", location: { x: linkerPos.x + 0.5, y: linkerPos.y, z: linkerPos.z + 0.5 }, maxDistance: 0.5 });
                if (markers.length === 0) { player.sendMessage("§c[키오스크 연동] 저장된 위치에 계산대가 존재하지 않습니다."); return; }
                const marker = markers[0];
                let linkedKiosks = JSON.parse(marker.getDynamicProperty("linkedKiosks") || "[]");
                if (!linkedKiosks.includes(kioskKey)) {
                    linkedKiosks.push(kioskKey);
                    marker.setDynamicProperty("linkedKiosks", JSON.stringify(linkedKiosks));
                }
                player.sendMessage(`§a[키오스크 연동] 성공적으로 계산대(${linkerPos.x}, ${linkerPos.y}, ${linkerPos.z})와 키오스크가 연동되었습니다!`);
                return;
            }
            
            const allPosMarkers = player.dimension.getEntities({ type: "nf:pos_marker" });
            let myPosMarker = null;
            for (const marker of allPosMarkers) {
                let linkedKiosks = JSON.parse(marker.getDynamicProperty("linkedKiosks") || "[]");
                if (linkedKiosks.includes(kioskKey)) { myPosMarker = marker; break; }
            }
            
            if (!myPosMarker) {
                player.sendMessage("§c[키오스크] 연결된 계산대가 없습니다. 키오스크 연결 막대기(nf:kiosk_linker)로 계산대와 연동해 주세요.");
                return;
            }
            
            showKioskMainUI(player, myPosMarker);
        });
    } else if (block.typeId === "minecraft:chest" || block.typeId === "minecraft:trapped_chest") {
        // 일반 상자 터치 시 연동된 마커가 있으면 원격 배송 대기열 자동 적재 실행
        system.run(() => {
            const allMarkers = player.dimension.getEntities({ type: "nf:pos_marker" });
            const myMarker = allMarkers.find(m => {
                let locStr = m.getDynamicProperty("stockBoxLoc");
                if (!locStr) return false; let loc = JSON.parse(locStr);
                return loc.x === block.location.x && loc.y === block.location.y && loc.z === block.location.z;
            });
            if (myMarker) checkAndProcessPendingSupplies(player.dimension, myMarker);
        });
        
        // 손에 상자 연결 막대기(nf:box_linker)를 들고 일반 상자를 클릭하면 계산대와 연동 (상자 블록은 그대로 유지)
        const equip = player.getComponent("equippable");
        const mainhand = equip ? equip.getEquipment("Mainhand") : undefined;
        if (!mainhand || mainhand.typeId !== "nf:box_linker") return; // 막대기 없으면 상자 UI 정상 오픈
        
        event.cancel = true; // 막대기 들고 있을 때만 이벤트 취소
        system.run(() => {
            const linkerPosStr = player.getDynamicProperty("box_linker_pos");
            if (!linkerPosStr) {
                player.sendMessage("§c[상자 연결] 먼저 계산대(nf:pos_terminal)를 상자 연결 막대기로 터치해 주세요.");
                return;
            }
            const linkerPos = JSON.parse(linkerPosStr);
            if (linkerPos.dim !== player.dimension.id) {
                player.sendMessage("§c[상자 연결] 같은 차원의 계산대만 연동 가능합니다.");
                return;
            }
            
            const markers = player.dimension.getEntities({
                type: "nf:pos_marker",
                location: { x: linkerPos.x + 0.5, y: linkerPos.y, z: linkerPos.z + 0.5 },
                maxDistance: 0.5
            });
            if (markers.length === 0) {
                player.sendMessage("§c[상자 연결] 저장된 위치에 계산대 마커가 없습니다. 다시 계산대를 터치해 주세요.");
                return;
            }
            const posMarker = markers[0];
            if (posMarker.getDynamicProperty("pos_owner") !== player.name) {
                player.sendMessage("§c[상자 연결] 본인 소유의 계산대에만 연동할 수 있습니다.");
                return;
            }
            
            new ActionFormData().title("§l상자 연동 용도 선택").body("이 일반 상자를 어떤 용도의 재고 상자로 연동하시겠습니까?\n§7(기존 상자 내부 아이템 및 외형은 그대로 유지됩니다)")
            .button("§a🛒 상점 재고 상자 (키오스크 판매용)")
            .button("§e🚚 납품업체 재고 상자 (물류 배송용)")
            .show(player).then(r => {
                if (r.canceled) return;
                const isStore = r.selection === 0;
                const propName = isStore ? "stockBoxLoc" : "supplierBoxLoc";
                const boxName  = isStore ? "상점 재고 상자" : "납품업체 재고 상자";
                
                posMarker.setDynamicProperty(propName, JSON.stringify({
                    x: block.location.x,
                    y: block.location.y,
                    z: block.location.z
                }));
                player.sendMessage(`§a[상자 연결 완료] 일반 상자가 성공적으로 §e${boxName}§a(으)로 계산대(${linkerPos.x}, ${linkerPos.y}, ${linkerPos.z})와 연동되었습니다!`);
            });
        });
    } else if (block.typeId === "nf:trade_port") {
        event.cancel = true;
        system.run(() => {
            new ActionFormData().title("§l무역 및 금융 센터").body("원하시는 시스템을 선택하세요.")
            .button("§a[물물교환] P2P 무역 테이블")
            .button("§6[증권거래소] 실시간 주식 시장")
            .button("§b[계좌이체] 플레이어 송금")
            .button("§d[국고 조회] 국가 및 서버 계좌")
            .button("닫기")
            .show(player).then(res => {
                if (res.canceled || res.selection === 4) return;
                if (res.selection === 0) {
                    let finalStr = JSON.parse(world.getDynamicProperty("final_trade_" + player.name) || "null");
                    let pendingStr = JSON.parse(world.getDynamicProperty("pending_trade_" + player.name) || "null");
                    if (finalStr) showFinalTradeMenu(player, finalStr);
                    else if (pendingStr) showTradeReplyMenu(player, pendingStr);
                    else showP2PTradeMenu(player);
                } else if (res.selection === 1) {
                    showStockMarketUI(player);
                } else if (res.selection === 2) {
                    showWireTransferUI(player);
                } else if (res.selection === 3) {
                    showTreasuryUI(player);
                }
            });
        });
    } else if (block.typeId === "nf:casino_exchange") {
        event.cancel = true;
        system.run(() => {
            const loc = block.location;
            const exKey = `exchange_${loc.x}_${loc.y}_${loc.z}_${player.dimension.id}`;
            let exData = JSON.parse(world.getDynamicProperty(exKey) || "null");
            
            if (!exData) {
                new ActionFormData().title("§l카지노 칩 환전기").body("아직 카지노 오너가 등록되지 않았습니다.")
                .button("§a카지노 오너 등록하기")
                .show(player).then(res => {
                    if (res.canceled) return;
                    exData = { owner: player.name, winRate: 43, revenue: 0, taxPaid: 0, linkedMachines: [] };
                    world.setDynamicProperty(exKey, JSON.stringify(exData));
                    player.sendMessage("§a[카지노 관리] 카지노 오너 등록이 완료되었습니다.");
                });
                return;
            }
            
            if (player.name === exData.owner) {
                let revStr = exData.revenue >= 0 ? `§a+${exData.revenue.toLocaleString()}₩ (흑자)` : `§c${exData.revenue.toLocaleString()}₩ (적자)`;
                new ActionFormData().title("§l카지노 오너 관리기").body(`§e[카지노 총 매출] ${revStr}\n§6[납부 세금 총액] §b${exData.taxPaid.toLocaleString()}₩\n§7현재 설정된 당첨 확률: §d${exData.winRate}%`)
                .button("§a🎰 카지노 기계 연결 (연결막대기)")
                .button("§b⚙️ 기계 당첨 확률 설정")
                .button("§6📈 카지노 매출 및 세금 확인")
                .button("§d💰 칩 환전소 이용 (일반 모드)")
                .button("§c⚠️ 오너 등록 해제 (초기화)")
                .show(player).then(res => {
                    if (res.canceled) return;
                    if (res.selection === 0) {
                        player.setDynamicProperty("casino_linker_pos", JSON.stringify({ key: exKey, x: loc.x, y: loc.y, z: loc.z, dim: player.dimension.id }));
                        player.sendMessage("§a[카지노 연동] 환전기 위치가 저장되었습니다. 손에 키오스크 연결 막대기(nf:kiosk_linker)를 들고 카지노 머신(nf:casino_machine)을 터치하세요!");
                    } else if (res.selection === 1) {
                        new ModalFormData().title("기계 당첨 확률 설정").textField("당첨 확률을 입력하세요 (10 ~ 90%)", "예: 43", String(exData.winRate))
                        .show(player).then(r => {
                            if (r.canceled) return; let rate = parseInt(r.formValues[0]); if(isNaN(rate) || rate < 10 || rate > 90) { player.sendMessage("§c10에서 90 사이의 숫자를 입력하세요."); return; }
                            exData.winRate = rate; world.setDynamicProperty(exKey, JSON.stringify(exData));
                            player.sendMessage(`§a[카지노 관리] 기계 당첨 확률이 ${rate}%로 설정되었습니다.`);
                        });
                    } else if (res.selection === 2) {
                        player.sendMessage(`§e[카지노 재무 정보]\n§f- 총 매출액: ${revStr}\n§f- 국가 및 서버 납부 세금 총액: §b${exData.taxPaid.toLocaleString()}₩`);
                    } else if (res.selection === 3) {
                        showCasinoExchangeGuestUI(player, exKey, exData);
                    } else if (res.selection === 4) {
                        world.setDynamicProperty(exKey, undefined);
                        player.sendMessage("§a[카지노 관리] 환전기가 초기화되었습니다.");
                    }
                });
            } else {
                showCasinoExchangeGuestUI(player, exKey, exData);
            }
        });
    } else if (block.typeId === "nf:casino_machine") {
        event.cancel = true;
        system.run(() => {
            const loc = block.location;
            const key = `casino_${loc.x}_${loc.y}_${loc.z}`;
            let machineData = JSON.parse(world.getDynamicProperty(key) || "null");
            
            const equip = player.getComponent("equippable");
            const mainhand = equip ? equip.getEquipment("Mainhand") : undefined;
            
            if (mainhand && mainhand.typeId === "nf:kiosk_linker") {
                let linkerPosStr = player.getDynamicProperty("casino_linker_pos");
                if (!linkerPosStr) { player.sendMessage("§c[카지노 연동] 먼저 카지노 칩 환전기(nf:casino_exchange)를 터치하여 오너 위치를 저장해 주세요."); return; }
                let linkerPos = JSON.parse(linkerPosStr);
                if (linkerPos.dim !== player.dimension.id) { player.sendMessage("§c[카지노 연동] 같은 차원의 환전기만 연동 가능합니다."); return; }
                
                let exData = JSON.parse(world.getDynamicProperty(linkerPos.key) || "null");
                if (!exData) { player.sendMessage("§c[카지노 연동] 환전기 정보가 유효하지 않습니다."); return; }
                if (exData.owner !== player.name) { player.sendMessage("§c[카지노 연동] 본인 소유의 환전기만 연동할 수 있습니다."); return; }
                
                if (!exData.linkedMachines) exData.linkedMachines = [];
                if (!exData.linkedMachines.includes(key)) {
                    exData.linkedMachines.push(key);
                    world.setDynamicProperty(linkerPos.key, JSON.stringify(exData));
                }
                
                if (!machineData) machineData = { balance: 0, owner: player.name, lastGamer: player.name, waiting: true, loc: { x: loc.x, y: loc.y, z: loc.z, dim: player.dimension.id } };
                machineData.linkedExchangeKey = linkerPos.key; machineData.owner = player.name; machineData.lastGamer = player.name;
                world.setDynamicProperty(key, JSON.stringify(machineData));
                
                player.sendMessage(`§a[카지노 연동] 성공적으로 카지노 머신과 환전기(${linkerPos.x}, ${linkerPos.y}, ${linkerPos.z})가 연동되었습니다!`);
                return;
            }
            
            const isChip1k = mainhand && mainhand.typeId === "nf:chip_1k";
            const isChip10k = mainhand && mainhand.typeId === "nf:chip_10k";
            
            if (isChip1k || isChip10k) {
                const addAmt = isChip1k ? 1000 : 10000;
                if (!machineData) {
                    machineData = { balance: addAmt, owner: player.name, lastGamer: player.name, waiting: true, loc: { x: loc.x, y: loc.y, z: loc.z, dim: player.dimension.id } };
                } else { machineData.balance += addAmt; machineData.lastGamer = player.name; machineData.waiting = true; }
                world.setDynamicProperty(key, JSON.stringify(machineData));
                
                let activeList = JSON.parse(world.getDynamicProperty("active_casino_machines") || "[]");
                if (!activeList.includes(key)) { activeList.push(key); world.setDynamicProperty("active_casino_machines", JSON.stringify(activeList)); }
                
                if (mainhand.amount > 1) { mainhand.amount--; equip.setEquipment("Mainhand", mainhand); }
                else { equip.setEquipment("Mainhand", undefined); }
                
                player.runCommand(`titleraw @s actionbar {"rawtext":[{"text":"§e[카지노 칩 투입] §a+${addAmt.toLocaleString()}₩ §f| 현재 총 베팅액: §b${machineData.balance.toLocaleString()}₩"}]}`);
                try { player.playSound("random.orb", { location: loc }); } catch(e){}
            } else {
                if (machineData && machineData.balance > 0) {
                    const balance = machineData.balance;
                    machineData.balance = 0; machineData.waiting = false;
                    world.setDynamicProperty(key, JSON.stringify(machineData));
                    
                    let exData = machineData.linkedExchangeKey ? JSON.parse(world.getDynamicProperty(machineData.linkedExchangeKey) || "null") : null;
                    const winRate = exData ? exData.winRate : 43;
                    const isWin = Math.random() < (winRate / 100);
                    const dim = player.dimension;
                    const gamerName = machineData.lastGamer || player.name;
                    
                    if (isWin) {
                        const winAmt = balance * 2;
                        try { dim.runCommand(`scoreboard players add "${gamerName}" player_money ${winAmt}`); } catch(e){}
                        try { player.runCommand(`titleraw @s actionbar {"rawtext":[{"text":"§a🎉 JACKPOT! §f${winAmt.toLocaleString()}₩ 당첨!"}]}`); } catch(e){}
                        try { dim.playSound("random.levelup", { location: loc }); dim.playSound("note.pling", { location: loc }); } catch(e){}
                        
                        if (exData) {
                            exData.revenue -= winAmt;
                            world.setDynamicProperty(machineData.linkedExchangeKey, JSON.stringify(exData));
                            try { dim.runCommand(`tellraw "${exData.owner}" {"rawtext":[{"text":"§c[카지노 알림] 손님이 기계에서 ${winAmt.toLocaleString()}₩ 당첨되었습니다. (현재 총 매출: ${exData.revenue.toLocaleString()}₩)"}]}`); } catch(e){}
                        }
                    } else {
                        try { dim.playSound("mob.villager.no", { location: loc }); dim.playSound("note.bass", { location: loc }); } catch(e){}
                        
                        const serverFee = Math.floor(balance * 0.0514);
                        let pNation = JSON.parse(world.getDynamicProperty("player_nation_" + (exData ? exData.owner : machineData.owner)) || "null");
                        let nNames = JSON.parse(world.getDynamicProperty("nation_names") || "{}"); let nName = pNation ? (nNames[pNation] || pNation.replace("nation_id_", "국가 ")) : null;
                        
                        const taxRate = nName ? 10 : 0;
                        const nationTax = Math.floor(balance * (taxRate / 100));
                        const ownerNet = balance - serverFee - nationTax;
                        
                        try { dim.runCommand(`scoreboard players add "SERVER_BANK" treasury ${serverFee}`); } catch(e){}
                        if (nName) try { dim.runCommand(`scoreboard players add "${nName}" treasury ${nationTax}`); } catch(e){}
                        
                        if (exData) {
                            exData.revenue += ownerNet;
                            exData.taxPaid += (serverFee + nationTax);
                            world.setDynamicProperty(machineData.linkedExchangeKey, JSON.stringify(exData));
                            try { dim.runCommand(`tellraw "${exData.owner}" {"rawtext":[{"text":"§a[카지노 알림] 손님이 베팅에 실패하여 순수익 ${ownerNet.toLocaleString()}₩이 적립되었습니다. (납부 세금: ${(serverFee+nationTax).toLocaleString()}₩)"}]}`); } catch(e){}
                        }
                        player.runCommand(`titleraw @s actionbar {"rawtext":[{"text":"§c꽝! 베팅 금액(${balance.toLocaleString()}₩)을 잃었습니다."}]}`);
                    }
                } else {
                    player.runCommand(`titleraw @s actionbar {"rawtext":[{"text":"§7[카지노 머신 비어 있음] §f카지노 칩(1k/10k)을 들고 터치하세요"}]}`);
                }
            }
        });
    }
});


// ====== POS 기기 헬퍼 함수 ======
function showPosIPOUI(player, marker) {
    new ModalFormData().title("§l기업 주식 상장 (IPO)")
    .textField("상장할 기업/종목명", "예: 데릭 컴퍼니", player.name + " 컴퍼니")
    .textField("초기 공모 주가 (₩)", "예: 5000", "5000")
    .textField("초기 자본금/매출액 (₩)", "예: 1000000", "1000000")
    .textField("초기 채무액 (₩)", "예: 0", "0")
    .show(player).then(r => {
        if (r.canceled) return;
        const name = r.formValues[0];
        const price = parseInt(r.formValues[1]);
        const rev = parseInt(r.formValues[2]);
        const debt = parseInt(r.formValues[3]);
        
        if (!name || name === "" || isNaN(price) || price <= 0 || isNaN(rev) || isNaN(debt)) {
            player.sendMessage("§c입력값이 올바르지 않습니다."); return;
        }
        
        let stocks = JSON.parse(world.getDynamicProperty("stock_market") || JSON.stringify(defaultStocks));
        const key = "ipo_" + Date.now();
        stocks[key] = { name: name, price: price, revenue: rev, debt: debt, history: [price], fluc: 0.05 };
        world.setDynamicProperty("stock_market", JSON.stringify(stocks));
        
        player.runCommand(`tellraw @a {"rawtext":[{"text":"§e[증권거래소 공지] §a${player.name}§f님의 기업 §b'${name}'§f이(가) 공모가 §e${price.toLocaleString()}₩§f에 신규 상장되었습니다!"}]}`);
    });
}

function showPosCatalogUI(player, marker) {
    let catalog = JSON.parse(marker.getDynamicProperty("pos_catalog") || "[]");
    const form = new ActionFormData().title("§l판매 상품 관리").body("현재 영구 등록된 상품 목록입니다.");
    form.button("§a+ 새 상품 영구 등록 (인벤토리에서)");
    for (let i = 0; i < catalog.length; i++) {
        form.button(`§c[삭제] §f${catalog[i].name} (개당 ${catalog[i].price.toLocaleString()}₩)`);
    }
    form.button("§7뒤로 가기");
    
    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) {
            const invComp = player.getComponent("inventory") || player.getComponent("minecraft:inventory");
            if (!invComp) return;
            const inventory = invComp.container;
            const items = []; const options = [];
            
            for (let i = 0; i < inventory.size; i++) {
                const item = inventory.getItem(i);
                if (item) {
                    items.push({ slot: i, item: item });
                    options.push(`${item.typeId.replace("minecraft:", "")} (보유: ${item.amount}개)`);
                }
            }
            if (items.length === 0) { player.sendMessage("§c인벤토리에 등록할 아이템이 없습니다."); return; }
            
            new ModalFormData().title("§l새 판매 상품 영구 등록")
            .dropdown("등록할 아이템 선택", options)
            .textField("개당 판매 가격 (₩)", "예: 1000")
            .show(player).then(r => {
                if (r.canceled) return;
                const idx = r.formValues[0];
                const price = parseInt(r.formValues[1]);
                if (isNaN(price) || price <= 0) { player.sendMessage("§c올바른 가격을 입력하세요."); return; }
                
                const selectedItem = items[idx].item;
                const name = selectedItem.typeId.replace("minecraft:", "");
                catalog.push({ typeId: selectedItem.typeId, name: name, price: price });
                marker.setDynamicProperty("pos_catalog", JSON.stringify(catalog));
                player.sendMessage(`§a[POS] '${name}' 상품이 개당 ${price.toLocaleString()}₩에 영구 등록되었습니다!`);
                showPosCatalogUI(player, marker);
            });
        } else if (res.selection <= catalog.length) {
            const delIdx = res.selection - 1;
            const delName = catalog[delIdx].name; catalog.splice(delIdx, 1);
            marker.setDynamicProperty("pos_catalog", JSON.stringify(catalog));
            player.sendMessage(`§c[POS] '${delName}' 상품이 목록에서 삭제되었습니다.`);
            showPosCatalogUI(player, marker);
        }
    });
}

function showPosSellUI(player, marker) {
    let catalog = JSON.parse(marker.getDynamicProperty("pos_catalog") || "[]");
    if (catalog.length === 0) {
        player.sendMessage("§c[POS] 등록된 상품이 없습니다. '판매 상품 관리'에서 먼저 상품을 영구 등록하세요."); return;
    }
    
    let cart = JSON.parse(marker.getDynamicProperty("pos_cart") || "[]");
    let cartTotal = cart.reduce((sum, item) => sum + item.price, 0);
    let cartSummary = cart.length === 0 ? "§7(장바구니 비어 있음)" : cart.map(c => `§f- ${c.name} x${c.amount} (${c.price.toLocaleString()}₩)`).join("\n");
    
    const form = new ActionFormData().title("§lPOS 장바구니 계산")
    .body(`§e[현재 장바구니 목록]\n${cartSummary}\n\n§a💰 총 합계 금액: ${cartTotal.toLocaleString()}₩\n\n원하시는 작업을 선택하세요.`);
    
    form.button("§a+ 장바구니에 상품 추가");
    if (cart.length > 0) {
        form.button("§e🚀 [결제 대기] 손님 결제 요청하기");
        form.button("§c🗑️ 장바구니 전체 비우기");
    }
    form.button("§7닫기");
    
    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) {
            const options = catalog.map(c => `${c.name} (개당 ${c.price.toLocaleString()}₩)`);
            new ModalFormData().title("§l장바구니 상품 추가")
            .dropdown("추가할 상품 선택", options)
            .slider("수량 선택", 1, 64, 1, 1)
            .show(player).then(r => {
                if (r.canceled) return;
                const selected = catalog[r.formValues[0]];
                const amount = r.formValues[1];
                const itemTotal = selected.price * amount;
                
                cart.push({ typeId: selected.typeId, name: selected.name, amount: amount, price: itemTotal });
                marker.setDynamicProperty("pos_cart", JSON.stringify(cart));
                player.sendMessage(`§a[POS] 장바구니 추가: ${selected.name} x${amount} (+${itemTotal.toLocaleString()}₩)`);
                showPosSellUI(player, marker);
            });
        } else if (res.selection === 1 && cart.length > 0) {
            marker.setDynamicProperty("pos_active_cart", JSON.stringify(cart));
            marker.setDynamicProperty("pos_cart", "[]");
            marker.nameTag = `§e[결제 대기중] §f상품 ${cart.length}종 합계\n§a총액: ${cartTotal.toLocaleString()}₩\n§b카드를 들고 터치하세요`;
            player.sendMessage(`§a[POS] 결제 대기 시작! 총액 ${cartTotal.toLocaleString()}₩ (손님이 카드로 터치하면 결제됩니다)`);
        } else if (res.selection === 2 && cart.length > 0) {
            marker.setDynamicProperty("pos_cart", "[]");
            player.sendMessage("§c[POS] 장바구니를 비웠습니다.");
            showPosSellUI(player, marker);
        }
    });
}

function processPosPayment(player, marker, owner, cart) {
    const equip = player.getComponent("equippable");
    const mainhand = equip ? equip.getEquipment("Mainhand") : undefined;
    if (!mainhand || (mainhand.typeId !== "nf:check_card" && mainhand.typeId !== "nf:credit_card")) return;
    
    const customerNationId = getNationId(player);
    if (!customerNationId) { player.sendMessage("§c국가에 소속되어야 금융을 이용할 수 있습니다."); return; }
    const customerCurr = getCurrencyInfo(customerNationId);
    const ownerNationId = getNationId(owner); const ownerCurr = getCurrencyInfo(ownerNationId);
    
    const currentPrice = cart.reduce((sum, item) => sum + item.price, 0);
    const valueInGold = currentPrice * ownerCurr.rate;
    const customerPrice = Math.ceil(valueInGold / customerCurr.rate);
    
    const isCredit = (mainhand.typeId === "nf:credit_card");
    let customerMoney = 0;
    try { customerMoney = world.scoreboard.getObjective("player_money").getScore(player); } catch (e) {}

    if (isCredit) {
        let creditScore = JSON.parse(world.getDynamicProperty("credit_score_" + player.name) || "500");
        let debt = JSON.parse(world.getDynamicProperty("debt_" + player.name) || "0");
        let limit = creditScore * 100;
        
        if (customerPrice > (limit - debt)) {
            player.sendMessage(`§c[결제 실패] 한도 초과. (지불 금액: ${customerPrice.toLocaleString()} ${customerCurr.symbol})`); return;
        }
        world.setDynamicProperty("debt_" + player.name, JSON.stringify(debt + customerPrice));
        player.sendMessage(`§a[결제 완료] 신용 승인: ${customerPrice.toLocaleString()} ${customerCurr.symbol} 결제됨.`);
    } else {
        if (customerMoney < customerPrice) { 
            player.sendMessage(`§c[결제 실패] 잔액 부족. (필요: ${customerPrice.toLocaleString()} ${customerCurr.symbol}, 환율 적용됨)`); return; 
        }
        player.runCommand(`scoreboard players remove @s player_money ${customerPrice}`);
        player.sendMessage(`§a[결제 완료] ${customerPrice.toLocaleString()} ${customerCurr.symbol} 차감됨. (환율 자동 적용)`);
    }
    
    const fee = Math.floor(currentPrice * 0.05); const ownerIncome = currentPrice - fee;
    player.dimension.runCommand(`scoreboard players add "${owner}" player_money ${ownerIncome}`);
    try { player.dimension.runCommand(`tellraw "${owner}" {"rawtext":[{"text":"§a[POS] ${ownerIncome.toLocaleString()} ${ownerCurr.symbol} 입금됨! (수수료 ${fee.toLocaleString()} 공제, 상품 ${cart.length}종 판매)"}]}`); } catch(e) {}
    
    for (const item of cart) { player.runCommand(`give @s ${item.typeId} ${item.amount}`); }
    marker.setDynamicProperty("pos_active_cart", ""); marker.nameTag = `§e${owner}의 상점`;
}

// ====== P2P 무역 및 송금 로직 ======
function showWireTransferUI(player) {
    const otherPlayers = world.getAllPlayers().filter(p => p.name !== player.name);
    if (otherPlayers.length === 0) { player.sendMessage("§c현재 접속 중인 다른 플레이어가 없습니다."); return; }
    const options = otherPlayers.map(p => p.name);
    let money = 0; try { money = world.scoreboard.getObjective("player_money").getScore(player); } catch(e){}
    
    new ModalFormData().title("§l계좌 이체 (송금)")
    .dropdown(`받는 사람 선택 (내 잔액: ${money.toLocaleString()}₩)`, options)
    .textField("송금할 금액 (₩)", "예: 10000")
    .show(player).then(r => {
        if (r.canceled) return;
        const targetPlayer = otherPlayers[r.formValues[0]]; const amount = parseInt(r.formValues[1]);
        if (isNaN(amount) || amount <= 0) { player.sendMessage("§c올바른 금액을 입력하세요."); return; }
        if (money < amount) { player.sendMessage("§c잔액이 부족합니다."); return; }
        
        player.runCommand(`scoreboard players remove @s player_money ${amount}`);
        targetPlayer.runCommand(`scoreboard players add @s player_money ${amount}`);
        player.sendMessage(`§a[송금 완료] ${targetPlayer.name}님에게 ${amount.toLocaleString()}₩을 송금했습니다.`);
        targetPlayer.sendMessage(`§a[은행 입금] ${player.name}님으로부터 ${amount.toLocaleString()}₩이 입금되었습니다!`);
    });
}

function showP2PTradeMenu(player) {
    const players = player.dimension.getPlayers({ location: player.location, maxDistance: 5 });
    const nearby = players.filter(p => p.name !== player.name);
    if (nearby.length === 0) {
        player.sendMessage("§c[무역 포트] 주변(5블록 이내)에 거래할 다른 플레이어가 없습니다.\n§7(무역 테이블은 2명의 플레이어가 마주보고 거래하는 시스템입니다)"); return;
    }
    const options = nearby.map(p => p.name);
    new ModalFormData().title("§l무역 포트 (1:1 거래)").dropdown("거래 상대 선택", options)
    .show(player).then(res => {
        if (res.canceled) return;
        const targetPlayerName = options[res.formValues[0]];
        const targetPlayer = nearby.find(p => p.name === targetPlayerName);
        if (!targetPlayer) return;

        const invComp = player.getComponent("inventory") || player.getComponent("minecraft:inventory");
        if (!invComp) return; const inventory = invComp.container;
        const items = []; const itemOptions = [];
        for (let i = 0; i < inventory.size; i++) {
            const item = inventory.getItem(i);
            if (item) { items.push({ slot: i, item: item }); itemOptions.push(`${item.typeId.replace("minecraft:", "")} x${item.amount}`); }
        }
        if (items.length === 0) { player.sendMessage("§c거래할 아이템이 인벤토리에 없습니다."); return; }

        new ModalFormData().title(`§l무역 제안 -> ${targetPlayerName}`)
        .dropdown("내가 줄 아이템 선택", itemOptions)
        .textField("상대에게 요구할 자금 (단위: ₩)", "예: 5000")
        .show(player).then(r => {
            if (r.canceled) return;
            const selected = items[r.formValues[0]]; const price = parseInt(r.formValues[1]);
            if (isNaN(price) || price < 0) { player.sendMessage("§c올바른 금액을 입력하세요."); return; }

            const item = inventory.getItem(selected.slot); if (!item) return;
            inventory.setItem(selected.slot, undefined);

            const tradeData = {
                sender: player.name, recipient: targetPlayerName,
                item: { typeId: item.typeId, amount: item.amount }, price: price
            };
            world.setDynamicProperty("pending_trade_" + targetPlayerName, JSON.stringify(tradeData));
            targetPlayer.sendMessage(`§a[무역 포트] ${player.name}님으로부터 거래 제안이 도착했습니다! 무역 포트를 클릭하여 확인하세요.`);
            player.sendMessage(`§a[무역 포트] ${targetPlayerName}님에게 거래를 제안했습니다.`);
        });
    });
}

function showTradeReplyMenu(player, tradeData) {
    const itemName = tradeData.item.typeId.replace("minecraft:", "");
    new ActionFormData().title("§l도착한 무역 제안")
    .body(`§e${tradeData.sender}§f님의 제안:\n\n§b[받을 아이템]§f ${itemName} x${tradeData.item.amount}\n§c[지불할 금액]§f ${tradeData.price.toLocaleString()}₩`)
    .button("§a수락 (결제 및 거래 진행)").button("§c거절")
    .show(player).then(res => {
        world.setDynamicProperty("pending_trade_" + player.name, undefined);
        if (res.canceled || res.selection === 1) {
            const senderPlayer = world.getAllPlayers().find(p => p.name === tradeData.sender);
            if (senderPlayer) {
                senderPlayer.sendMessage(`§c[무역 포트] ${player.name}님이 거래 제안을 거절했습니다.`);
                senderPlayer.runCommand(`give @s ${tradeData.item.typeId} ${tradeData.item.amount}`);
            }
            player.sendMessage("§c거래 제안을 거절했습니다.");
            return;
        }

        let money = 0; try { money = world.scoreboard.getObjective("player_money").getScore(player); } catch(e){}
        if (money < tradeData.price) {
            player.sendMessage("§c잔액이 부족하여 거래를 수락할 수 없습니다.");
            const senderPlayer = world.getAllPlayers().find(p => p.name === tradeData.sender);
            if(senderPlayer) senderPlayer.runCommand(`give @s ${tradeData.item.typeId} ${tradeData.item.amount}`);
            return;
        }

        player.runCommand(`scoreboard players remove @s player_money ${tradeData.price}`);
        player.runCommand(`give @s ${tradeData.item.typeId} ${tradeData.item.amount}`);

        const finalData = { sender: tradeData.sender, recipient: player.name, price: tradeData.price, itemName: itemName, amount: tradeData.item.amount };
        world.setDynamicProperty("final_trade_" + tradeData.sender, JSON.stringify(finalData));

        const senderPlayer = world.getAllPlayers().find(p => p.name === tradeData.sender);
        if (senderPlayer) {
            senderPlayer.sendMessage(`§a[무역 포트] ${player.name}님이 거래를 수락했습니다! 무역 포트를 클릭하여 대금을 수령하세요.`);
        }
        player.sendMessage(`§a[무역 포트] 거래가 완료되었습니다! (${tradeData.price.toLocaleString()}₩ 지불)`);
    });
}

function showFinalTradeMenu(player, finalData) {
    new ActionFormData().title("§l무역 대금 수령")
    .body(`§a${finalData.recipient}§f님과의 거래가 완료되었습니다.\n\n§b[판매한 아이템]§f ${finalData.itemName} x${finalData.amount}\n§e[수령할 대금]§f ${finalData.price.toLocaleString()}₩`)
    .button("§a대금 수령하기")
    .show(player).then(res => {
        if (res.canceled) return;
        world.setDynamicProperty("final_trade_" + player.name, undefined);
        player.runCommand(`scoreboard players add @s player_money ${finalData.price}`);
        player.sendMessage(`§a[무역 포트] 성공적으로 ${finalData.price.toLocaleString()}₩을 수령했습니다!`);
    });
}

// ====== 증권 거래소 (Stock Market) 로직 ======
let defaultStocks = {
    "mining": { name: "국영 광업 공사", price: 5000, revenue: 1500000, debt: 200000, history: [5000], fluc: 0.05 },
    "arms": { name: "크리퍼 무기 산업", price: 12000, revenue: 4800000, debt: 1500000, history: [12000], fluc: 0.08 },
    "bank": { name: "베드락 건설 은행", price: 25000, revenue: 9500000, debt: 500000, history: [25000], fluc: 0.03 }
};

function showStockMarketUI(player) {
    let stocks = JSON.parse(world.getDynamicProperty("stock_market") || JSON.stringify(defaultStocks));
    let playerStocks = JSON.parse(world.getDynamicProperty("player_stocks_" + player.name) || "{}");
    
    const form = new ActionFormData().title("§l증권 거래소 (Stock Exchange)")
    .body("실시간 주식 시세 및 보유 자산을 관리합니다.\n주가는 1분마다 변동하며 경제 상황에 영향을 받습니다.");
    
    const keys = Object.keys(stocks);
    for (const key of keys) {
        const st = stocks[key]; const myCount = playerStocks[key] || 0;
        form.button(`§e${st.name}\n§f현재가: ${st.price.toLocaleString()}₩ (보유: ${myCount}주)`);
    }
    form.button("§a내 주식 지갑 조회 및 전체 매도");
    form.button("닫기");
    
    form.show(player).then(res => {
        if (res.canceled || res.selection === keys.length + 1) return;
        if (res.selection < keys.length) {
            const key = keys[res.selection]; const st = stocks[key]; const myCount = playerStocks[key] || 0;
            
            new ActionFormData().title(`§l종목 상세 정보 - ${st.name}`)
            .body(`§e[기업 재무 상태]\n§f🏢 종목명: ${st.name}\n§a📈 현재 주가: ${st.price.toLocaleString()}₩\n§b💰 연간 매출액: ${(st.revenue || 1000000).toLocaleString()}₩\n§c📉 현재 채무 상태: ${(st.debt || 0).toLocaleString()}₩\n\n§7내 보유 수량: ${myCount}주\n\n원하시는 거래를 선택하세요.`)
            .button("§a주식 매수 (Buy)").button("§c주식 매도 (Sell)").button("뒤로 가기")
            .show(player).then(r => {
                if (r.canceled || r.selection === 2) { showStockMarketUI(player); return; }
                let money = 0; try { money = world.scoreboard.getObjective("player_money").getScore(player); } catch(e){}
                
                if (r.selection === 0) {
                    const maxBuy = Math.floor(money / st.price);
                    new ModalFormData().title(`§l주식 매수 - ${st.name}`)
                    .slider(`매수 수량 (현재가: ${st.price.toLocaleString()}₩ | 보유금액: ${money.toLocaleString()}₩)`, 1, Math.max(1, maxBuy > 64 ? 64 : maxBuy), 1, 1)
                    .show(player).then(r2 => {
                        if (r2.canceled) return; const amount = r2.formValues[0]; const totalCost = st.price * amount;
                        if (money < totalCost) { player.sendMessage("§c잔액이 부족합니다."); return; }
                        player.runCommand(`scoreboard players remove @s player_money ${totalCost}`);
                        playerStocks[key] = (playerStocks[key] || 0) + amount;
                        world.setDynamicProperty("player_stocks_" + player.name, JSON.stringify(playerStocks));
                        player.sendMessage(`§a[증권] ${st.name} ${amount}주를 ${totalCost.toLocaleString()}₩에 매수했습니다!`);
                        showStockMarketUI(player);
                    });
                } else if (r.selection === 1) {
                    if (myCount === 0) { player.sendMessage("§c보유 중인 주식이 없습니다."); showStockMarketUI(player); return; }
                    new ModalFormData().title(`§l주식 매도 - ${st.name}`)
                    .slider(`매도 수량 (현재가: ${st.price.toLocaleString()}₩ | 보유: ${myCount}주)`, 1, myCount, 1, 1)
                    .show(player).then(r2 => {
                        if (r2.canceled) return; const amount = r2.formValues[0]; const totalIncome = st.price * amount;
                        player.runCommand(`scoreboard players add @s player_money ${totalIncome}`);
                        playerStocks[key] -= amount; if (playerStocks[key] <= 0) delete playerStocks[key];
                        world.setDynamicProperty("player_stocks_" + player.name, JSON.stringify(playerStocks));
                        player.sendMessage(`§a[증권] ${st.name} ${amount}주를 매도하여 ${totalIncome.toLocaleString()}₩을 입금받았습니다!`);
                        showStockMarketUI(player);
                    });
                }
            });
        } else if (res.selection === keys.length) {
            const sellForm = new ActionFormData().title("§l내 주식 지갑 및 매도").body("보유 중인 주식을 매도(판매)할 수 있습니다.");
            const ownedKeys = keys.filter(k => (playerStocks[k] || 0) > 0);
            if (ownedKeys.length === 0) { sellForm.button("보유 중인 주식이 없습니다.").show(player).then(() => showStockMarketUI(player)); return; }
            for (const k of ownedKeys) { sellForm.button(`§c[매도] §f${stocks[k].name} (보유: ${playerStocks[k]}주 | 현재가: ${stocks[k].price.toLocaleString()}₩)`); }
            sellForm.button("뒤로 가기");
            sellForm.show(player).then(r => {
                if (r.canceled || r.selection === ownedKeys.length) { showStockMarketUI(player); return; }
                const k = ownedKeys[r.selection]; const st = stocks[k]; const myCount = playerStocks[k];
                new ModalFormData().title(`§l주식 매도 - ${st.name}`)
                .slider(`매도 수량 (현재가: ${st.price.toLocaleString()}₩ | 보유: ${myCount}주)`, 1, myCount, 1, 1)
                .show(player).then(res2 => {
                    if (res2.canceled) return; const amount = res2.formValues[0]; const totalIncome = st.price * amount;
                    player.runCommand(`scoreboard players add @s player_money ${totalIncome}`);
                    playerStocks[k] -= amount; if (playerStocks[k] <= 0) delete playerStocks[k];
                    world.setDynamicProperty("player_stocks_" + player.name, JSON.stringify(playerStocks));
                    player.sendMessage(`§a[증권] ${st.name} ${amount}주를 매도하여 ${totalIncome.toLocaleString()}₩을 입금받았습니다!`);
                    showStockMarketUI(player);
                });
            });
        }
    });
}

system.runInterval(() => {
    let stocks = JSON.parse(world.getDynamicProperty("stock_market") || JSON.stringify(defaultStocks));
    for (const key of Object.keys(stocks)) {
        let st = stocks[key];
        let changeRate = (Math.random() * (st.fluc * 2)) - st.fluc;
        if (Math.random() < 0.1) changeRate += (Math.random() > 0.5 ? 0.15 : -0.15);
        st.price = Math.max(500, Math.floor(st.price * (1 + changeRate)));
        st.revenue = Math.floor((st.revenue || 1000000) * (1 + (changeRate * 0.5)));
        st.history.push(st.price); if (st.history.length > 5) st.history.shift();
    }
    world.setDynamicProperty("stock_market", JSON.stringify(stocks));
}, 1200);

// ====== 신분증 및 은행/대출 UI ======
function showIdCardUI(player) {
    const nId = getNationId(player);
    let nationNames = JSON.parse(world.getDynamicProperty("nation_names") || "{}");
    
    if (!nId) {
        const availableNations = Object.keys(nationNames);
        const form = new ActionFormData().title("§l국가 포털 (무국적 상태)").body("현재 소속된 국가가 없습니다.\n원하시는 작업을 선택하세요.");
        if (availableNations.length > 0) form.button("§a국가 가입하기 (기존 국가 선택)");
        else form.button("§7[가입 불가] 생성된 국가 없음");
        form.button("§b국가 건국 안내 (현수막 사용)"); form.button("닫기");
        
        form.show(player).then(res => {
            if (res.canceled) return;
            if (res.selection === 0 && availableNations.length > 0) {
                const options = availableNations.map(id => `${nationNames[id]} (ID: ${id.replace("nation_id_", "")})`);
                new ModalFormData().title("§l국가 가입").dropdown("가입할 국가를 선택하세요.", options)
                .show(player).then(r => {
                    if (r.canceled) return; const selectedId = availableNations[r.formValues[0]];
                    player.addTag("has_nation"); player.addTag(selectedId);
                    const numId = selectedId.replace("nation_id_", "");
                    player.runCommand(`scoreboard players set @s nation_id ${numId}`);
                    world.setDynamicProperty("player_nation_" + player.name, selectedId);
                    player.sendMessage(`§a[안내] 성공적으로 '${nationNames[selectedId]}' 국가에 가입되었습니다!`);
                });
            } else if (res.selection === 1 || (res.selection === 0 && availableNations.length === 0)) {
                player.sendMessage("§e[건국 안내] §f모루에서 현수막(Banner)의 이름을 국가명으로 변경한 뒤, 손에 들고 허공을 클릭(사용)하면 나만의 국가가 건국됩니다!");
            }
        });
        return;
    }
    
    let hasId = JSON.parse(world.getDynamicProperty("id_issued_" + player.name) || "false");
    if (!hasId) {
        new ModalFormData().title("§l신분증 발급").textField("집 주소를 입력하세요.", "예: 서울시 강남구...")
        .show(player).then(res => {
            if (res.canceled) return; const address = res.formValues[0] || "알 수 없음";
            const passport = "M-" + Math.floor(Math.random() * 900000 + 100000);
            world.setDynamicProperty("id_address_" + player.name, JSON.stringify(address));
            world.setDynamicProperty("id_passport_" + player.name, JSON.stringify(passport));
            world.setDynamicProperty("id_issued_" + player.name, JSON.stringify(true));
            player.sendMessage("§a[안내] 신분증 발급이 완료되었습니다."); showIdCardUI(player);
        });
        return;
    }
    
    const address = JSON.parse(world.getDynamicProperty("id_address_" + player.name) || '"알 수 없음"');
    const passport = JSON.parse(world.getDynamicProperty("id_passport_" + player.name) || '"M-000000"');
    const displayNationName = nationNames[nId] || nId.replace("nation_id_", "국가 "); 
    const curr = getCurrencyInfo(nId);
    
    const form = new ActionFormData().title("§l신분증 및 국가 관리")
    .body(`§b소속 국가: §f${displayNationName}\n§e이름: §f${player.name}\n§a집 주소: §f${address}\n§6여권 번호: §f${passport}\n\n§7화폐 기호: ${curr.symbol} | 세금 비율: ${curr.tax_rate || 50} Gold 기준`);
    
    form.button("§e국고 및 경제 정보 조회");
    form.button("§b계좌 이체 (플레이어 송금)");
    form.button("§c국가 탈퇴하기");
    if (player.hasTag("nation_leader")) form.button("§6[지도자] 국가 설정 (이름/화폐/세금)");
    form.button("닫기");
    
    form.show(player).then(res => {
        if (res.canceled) return;
        if (res.selection === 0) {
            let treasury = 0; try { treasury = world.scoreboard.getObjective("treasury").getScore(player.dimension.getEntities({name: displayNationName})[0]); } catch(e){}
            player.sendMessage(`§e[국가 정보] §b${displayNationName}§f | 국고 잔액: ${treasury.toLocaleString()} ${curr.symbol} | 현재 환율: ${curr.rate.toFixed(4)}`);
        } else if (res.selection === 1) {
            showWireTransferUI(player);
        } else if (res.selection === 2) {
            new ActionFormData().title("§l국가 탈퇴 확인").body("정말로 소속 국가를 탈퇴하시겠습니까?\n§c(주의: 탈퇴 시 국가의 보호 및 혜택을 받을 수 없게 됩니다)")
            .button("§c탈퇴하기").button("§a취소")
            .show(player).then(r => {
                if (r.canceled || r.selection === 1) return;
                player.getTags().forEach(t => { if(t.startsWith("nation_id_") || t === "has_nation" || t === "nation_leader") player.removeTag(t); });
                player.runCommand("scoreboard players set @s nation_id 0");
                world.setDynamicProperty("player_nation_" + player.name, undefined);
                player.sendMessage("§c[안내] 국가에서 탈퇴하여 무국적자가 되었습니다.");
            });
        } else if (player.hasTag("nation_leader") && res.selection === 3) {
            new ModalFormData().title("§l국가 설정 관리")
            .textField("국가명 변경", "새 국가명 입력", displayNationName)
            .textField("화폐 기호/단위 변경", "예: KRW, USD", curr.symbol)
            .textField("영토당 세금 징수액 (기본 50)", "숫자 입력", String(curr.tax_rate || 50))
            .show(player).then(r => {
                if (r.canceled) return;
                const newName = r.formValues[0]; const newSym = r.formValues[1].toUpperCase(); const newTax = parseInt(r.formValues[2]);
                if (newName && newName !== "") nationNames[nId] = newName;
                if (newSym && newSym !== "") curr.symbol = newSym;
                if (!isNaN(newTax) && newTax >= 0) curr.tax_rate = newTax;
                
                let currencies = JSON.parse(world.getDynamicProperty("currencies") || "{}"); currencies[nId] = curr;
                world.setDynamicProperty("currencies", JSON.stringify(currencies));
                world.setDynamicProperty("nation_names", JSON.stringify(nationNames));
                player.sendMessage(`§a[국가 설정] 성공적으로 변경되었습니다!\n§f국가명: ${newName} | 화폐: ${newSym} | 세금: ${newTax}`);
            });
        }
    });
}

function showBankMenu(player) {
    const nId = getNationId(player); const curr = getCurrencyInfo(nId);
    let creditScore = JSON.parse(world.getDynamicProperty("credit_score_" + player.name) || "500");
    let debt = JSON.parse(world.getDynamicProperty("debt_" + player.name) || "0");
    let money = 0; try { money = world.scoreboard.getObjective("player_money").getScore(player); } catch(e) {}

    const form = new ActionFormData().title(`§l${curr.symbol} 은행 업무`)
        .body(`§e[환율 정보] 1 Gold = ${(1.0 / curr.rate).toFixed(2)} ${curr.symbol}\n\n§a[내 정보]\n§f잔액: ${money.toLocaleString()} ${curr.symbol}\n§c빚: ${Math.floor(debt).toLocaleString()} ${curr.symbol}\n§b신용 점수: ${Math.floor(creditScore)}점\n`)
        .button("대출 신청").button("대출 상환");
    if (player.hasTag("nation_leader")) form.button("§6[지도자] 중앙은행");
    form.button("닫기");

    form.show(player).then((res) => {
        if (res.canceled) return;
        if (res.selection === 0) showLoanApplyUI(player, creditScore, debt, curr);
        if (res.selection === 1) showLoanRepayUI(player, money, debt, creditScore, curr);
        if (player.hasTag("nation_leader") && res.selection === 2) showCentralBankUI(player, nId, curr);
    });
}

function showLoanApplyUI(player, creditScore, debt, curr) {
    let maxLoan = Math.max(0, (creditScore * 50) - debt);
    new ModalFormData().title("대출 신청").textField(`최대 대출: ${Math.floor(maxLoan).toLocaleString()} ${curr.symbol}`, "금액 입력")
    .show(player).then(res => {
        if(res.canceled) return; let amt = parseInt(res.formValues[0]); if(isNaN(amt) || amt <= 0) return;
        if(amt > maxLoan) { player.sendMessage("§c한도를 초과했습니다."); return; }
        player.runCommand(`scoreboard players add @s player_money ${amt}`);
        world.setDynamicProperty("debt_" + player.name, JSON.stringify(debt + amt));
        player.sendMessage(`§a[은행] ${amt.toLocaleString()} ${curr.symbol} 대출 승인.`);
    });
}

function showLoanRepayUI(player, money, debt, creditScore, curr) {
    new ModalFormData().title("대출 상환").textField(`잔액: ${money.toLocaleString()} ${curr.symbol}\n빚: ${Math.floor(debt).toLocaleString()} ${curr.symbol}`, "상환할 금액 입력")
    .show(player).then(res => {
        if(res.canceled) return; let amt = parseInt(res.formValues[0]); if(isNaN(amt) || amt <= 0) return;
        if(amt > money) { player.sendMessage("§c잔액 부족."); return; }
        if(amt > debt) amt = debt;
        player.runCommand(`scoreboard players remove @s player_money ${amt}`);
        world.setDynamicProperty("debt_" + player.name, JSON.stringify(debt - amt));
        world.setDynamicProperty("credit_score_" + player.name, JSON.stringify(Math.min(1000, creditScore + (amt / 1000))));
        player.sendMessage(`§a[은행] ${amt.toLocaleString()} ${curr.symbol} 상환 완료.`);
    });
}

function showCentralBankUI(player, nId, curr) {
    new ActionFormData().title(`§l${curr.symbol} 중앙은행 (지도자 전용)`)
        .body(`§b국가 통화 관리 시스템입니다.\n§f현재 통화량: ${curr.supply.toLocaleString()} ${curr.symbol}\n현재 환율: ${curr.rate.toFixed(4)}`)
        .button("화폐 기호 변경").button("통화 발행 (양적완화)").button("닫기")
        .show(player).then(res => {
            if (res.canceled || res.selection === 2) return;
            if (res.selection === 0) {
                new ModalFormData().title("화폐 기호 변경").textField("새로운 화폐 기호 (예: KRW, USD)", "문자 입력", curr.symbol)
                .show(player).then(r => {
                    if(r.canceled) return; let sym = r.formValues[0].toUpperCase();
                    if(sym.length > 0 && sym.length <= 5) {
                        let currencies = JSON.parse(world.getDynamicProperty("currencies") || "{}");
                        currencies[nId].symbol = sym; world.setDynamicProperty("currencies", JSON.stringify(currencies));
                        player.sendMessage(`§a[중앙은행] 화폐 기호가 ${sym} (으)로 변경되었습니다.`);
                    }
                });
            } else if (res.selection === 1) {
                new ModalFormData().title("통화 발행 (양적완화)").textField("새로 찍어낼 화폐 액수", "예: 50000")
                .show(player).then(r => {
                    if(r.canceled) return; let amt = parseInt(r.formValues[0]);
                    if(!isNaN(amt) && amt > 0) {
                        let currencies = JSON.parse(world.getDynamicProperty("currencies") || "{}");
                        let c = currencies[nId]; c.supply += amt; c.rate = 100000 / c.supply;
                        world.setDynamicProperty("currencies", JSON.stringify(currencies));
                        player.runCommand(`scoreboard players add @s player_money ${amt}`);
                        player.sendMessage(`§c[경고] §a${amt.toLocaleString()} ${c.symbol}§c 을 발행했습니다. 통화량 증가로 환율이 §e${c.rate.toFixed(4)}§c 로 하락했습니다.`);
                    }
                });
            }
        });
}

// ====== 백그라운드 루프 (국경선, 월세 출금, 대출이자) ======
function recalculateBorders(allFlagpoles) {
    let borderLines = []; const nationPoints = {};
    for (const [posKey, nId] of Object.entries(allFlagpoles)) {
        if (!nationPoints[nId]) nationPoints[nId] = [];
        const [x, y, z] = posKey.split(",").map(Number);
        nationPoints[nId].push({x, y, z});
    }
    for (const [nId, points] of Object.entries(nationPoints)) {
        for (let i = 0; i < points.length; i++) {
            for (let j = i + 1; j < points.length; j++) {
                const p1 = points[i]; const p2 = points[j];
                const dx = p1.x - p2.x; const dz = p1.z - p2.z;
                if ((dx*dx + dz*dz) <= 2500) borderLines.push({ p1, p2, nId });
            }
        }
    }
    world.setDynamicProperty("border_lines", JSON.stringify(borderLines));
}

system.runInterval(() => {
    const borderLinesStr = world.getDynamicProperty("border_lines"); if (!borderLinesStr) return;
    const borderLines = JSON.parse(borderLinesStr); if (borderLines.length === 0) return;
    
    for (const player of world.getAllPlayers()) {
        const px = player.location.x; const pz = player.location.z; const dim = player.dimension;
        for (const line of borderLines) {
            const midX = (line.p1.x + line.p2.x) / 2; const midZ = (line.p1.z + line.p2.z) / 2;
            if ((px - midX) ** 2 + (pz - midZ) ** 2 < 2500) {
                const steps = 15; const dx = (line.p2.x - line.p1.x) / steps; const dy = (line.p2.y - line.p1.y) / steps; const dz = (line.p2.z - line.p1.z) / steps;
                for (let i = 0; i <= steps; i++) {
                    dim.spawnParticle("minecraft:villager_happy", {x: line.p1.x + dx*i, y: line.p1.y + dy*i + 1.5, z: line.p1.z + dz*i});
                }
            }
        }
    }
}, 20);

// 현실시간 48분(57600틱)마다 주택 월세 및 점포 월세 출금
system.runInterval(() => {
    let estates = JSON.parse(world.getDynamicProperty("real_estates") || "[]");
    const overworld = world.getDimension("overworld");
    
    for (let bIdx = 0; bIdx < estates.length; bIdx++) {
        let estate = estates[bIdx];
        if (estate.type === 1 && estate.tenant !== "") { // 주택 임대
            overworld.runCommand(`scoreboard players remove "${estate.tenant}" player_money ${estate.price}`);
            overworld.runCommand(`scoreboard players add "${estate.owner}" player_money ${estate.price}`);
            try { overworld.runCommand(`tellraw "${estate.tenant}" {"rawtext":[{"text":"§e[부동산] 주택(${estate.name}) 월세 ${estate.price.toLocaleString()}₩이 자동 출금되었습니다."}]}`); } catch(e){}
            try { overworld.runCommand(`tellraw "${estate.owner}" {"rawtext":[{"text":"§a[부동산 입금] 주택(${estate.name}) 월세 ${estate.price.toLocaleString()}₩이 입금되었습니다."}]}`); } catch(e){}
        } else if (estate.type === 3) { // 상업용 건물
            let rooms = estate.rooms || [];
            for (let rIdx = 0; rIdx < rooms.length; rIdx++) {
                let room = rooms[rIdx];
                if (room.tenant !== "") {
                    overworld.runCommand(`scoreboard players remove "${room.tenant}" player_money ${room.price}`);
                    overworld.runCommand(`scoreboard players add "${estate.owner}" player_money ${room.price}`);
                    try { overworld.runCommand(`tellraw "${room.tenant}" {"rawtext":[{"text":"§e[부동산] 점포(${estate.name} ${room.name}) 월세 ${room.price.toLocaleString()}₩이 자동 출금되었습니다."}]}`); } catch(e){}
                    try { overworld.runCommand(`tellraw "${estate.owner}" {"rawtext":[{"text":"§a[부동산 입금] 점포(${estate.name} ${room.name}) 월세 ${room.price.toLocaleString()}₩이 입금되었습니다."}]}`); } catch(e){}
                }
            }
        }
    }
}, 57600);

system.runInterval(() => {
    const objMoney = world.scoreboard.getObjective("player_money");
    for (const player of world.getAllPlayers()) {
        let debt = JSON.parse(world.getDynamicProperty("debt_" + player.name) || "0");
        if (debt > 0) {
            debt = debt * 1.05; player.sendMessage(`§c[은행] 대출 이자 발생. 빚: ₩${Math.floor(debt).toLocaleString()}`);
            let money = 0; try { money = objMoney.getScore(player); } catch(e) {}
            if (money > 0) {
                const repayAmt = Math.min(money, Math.floor(debt));
                player.runCommand(`scoreboard players remove @s player_money ${repayAmt}`); debt -= repayAmt;
                let cScore = JSON.parse(world.getDynamicProperty("credit_score_" + player.name) || "500");
                world.setDynamicProperty("credit_score_" + player.name, JSON.stringify(Math.min(1000, cScore + (repayAmt / 1000))));
                player.sendMessage(`§a[은행] ${repayAmt.toLocaleString()} 자동 상환됨. 남은 빚: ₩${Math.floor(debt).toLocaleString()}`);
            } else {
                let cScore = JSON.parse(world.getDynamicProperty("credit_score_" + player.name) || "500");
                world.setDynamicProperty("credit_score_" + player.name, JSON.stringify(Math.max(0, cScore - 5)));
                player.sendMessage(`§4[은행 경고] 연체되어 신용 점수 하락!`);
            }
            world.setDynamicProperty("debt_" + player.name, JSON.stringify(debt));
        }
    }
}, 1200);

system.afterEvents.scriptEventReceive.subscribe((event) => {
    if (event.id === "nf:loan") {
        const player = event.sourceEntity; if (!player || player.typeId !== "minecraft:player") return;
        const msg = event.message; const nId = getNationId(player); const curr = getCurrencyInfo(nId);
        let creditScore = JSON.parse(world.getDynamicProperty("credit_score_" + player.name) || "500");
        let debt = JSON.parse(world.getDynamicProperty("debt_" + player.name) || "0");
        let money = 0; try { money = world.scoreboard.getObjective("player_money").getScore(player); } catch(e) {}
        
        if (msg === "apply") showLoanApplyUI(player, creditScore, debt, curr);
        else if (msg === "repay") showLoanRepayUI(player, money, debt, creditScore, curr);
    }
});

// ====== 카지노 백그라운드 루프 및 국고 관리 ======
system.runInterval(() => {
    let activeList = JSON.parse(world.getDynamicProperty("active_casino_machines") || "[]");
    if (activeList.length === 0) return;
    
    let newList = [];
    for (const key of activeList) {
        let machineData = JSON.parse(world.getDynamicProperty(key) || "null");
        if (!machineData || !machineData.waiting || machineData.balance <= 0) continue;
        
        const loc = machineData.loc;
        let dim; try { dim = world.getDimension(loc.dim); } catch(e){ continue; }
        let block; try { block = dim.getBlock(loc); } catch(e){ newList.push(key); continue; } // 언로드된 청크면 유지
        if (!block || block.typeId !== "nf:casino_machine") {
            world.setDynamicProperty(key, undefined); continue;
        }
        
        let isPowered = false;
        try { if (block.getRedstonePower && block.getRedstonePower() > 0) isPowered = true; } catch(e){}
        
        if (!isPowered) {
            const offsets = [{x:1,y:0,z:0},{x:-1,y:0,z:0},{x:0,y:1,z:0},{x:0,y:-1,z:0},{x:0,y:0,z:1},{x:0,y:0,z:-1}];
            for (const off of offsets) {
                try {
                    const adj = dim.getBlock({x: loc.x + off.x, y: loc.y + off.y, z: loc.z + off.z});
                    if (adj && (adj.typeId.includes("redstone_block") || adj.typeId.includes("lever") || adj.typeId.includes("button") || adj.typeId.includes("pressure_plate"))) {
                        if (adj.getRedstonePower && adj.getRedstonePower() > 0) { isPowered = true; break; }
                        if (adj.hasTag && adj.hasTag("powered")) { isPowered = true; break; }
                        const perm = adj.permutation;
                        if (perm.getState("open_bit") || perm.getState("button_pressed_bit")) { isPowered = true; break; }
                    }
                } catch(e){}
            }
        }
        
        if (isPowered) {
            machineData.waiting = false;
            const balance = machineData.balance; machineData.balance = 0;
            world.setDynamicProperty(key, JSON.stringify(machineData));
            
            let exData = machineData.linkedExchangeKey ? JSON.parse(world.getDynamicProperty(machineData.linkedExchangeKey) || "null") : null;
            const winRate = exData ? exData.winRate : 43;
            const isWin = Math.random() < (winRate / 100);
            const gamerName = machineData.lastGamer || machineData.owner;
            
            if (isWin) {
                const winAmt = balance * 2;
                try { dim.runCommand(`scoreboard players add "${gamerName}" player_money ${winAmt}`); } catch(e){}
                try { dim.playSound("random.levelup", { location: loc }); dim.playSound("note.pling", { location: loc }); } catch(e){}
                try { dim.runCommand(`tellraw "${gamerName}" {"rawtext":[{"text":"§a[카지노] 🎉 JACKPOT! 축하합니다! 카지노 머신에서 §e${winAmt.toLocaleString()}₩§a 당첨되었습니다!"}]}`); } catch(e){}
                
                if (exData) {
                    exData.revenue -= winAmt;
                    world.setDynamicProperty(machineData.linkedExchangeKey, JSON.stringify(exData));
                    try { dim.runCommand(`tellraw "${exData.owner}" {"rawtext":[{"text":"§c[카지노 알림] 손님이 기계에서 ${winAmt.toLocaleString()}₩ 당첨되었습니다. (현재 총 매출: ${exData.revenue.toLocaleString()}₩)"}]}`); } catch(e){}
                }
            } else {
                try { dim.playSound("mob.villager.no", { location: loc }); dim.playSound("note.bass", { location: loc }); } catch(e){}
                try { dim.runCommand(`tellraw "${gamerName}" {"rawtext":[{"text":"§c[카지노] 꽝! 아쉽게도 베팅 금액(${balance.toLocaleString()}₩)을 잃었습니다."}]}`); } catch(e){}
                
                const serverFee = Math.floor(balance * 0.0514);
                let pNation = JSON.parse(world.getDynamicProperty("player_nation_" + (exData ? exData.owner : machineData.owner)) || "null");
                let nNames = JSON.parse(world.getDynamicProperty("nation_names") || "{}"); let nName = pNation ? (nNames[pNation] || pNation.replace("nation_id_", "국가 ")) : null;
                
                const taxRate = nName ? 10 : 0;
                const nationTax = Math.floor(balance * (taxRate / 100));
                const ownerNet = balance - serverFee - nationTax;
                
                try { dim.runCommand(`scoreboard players add "SERVER_BANK" treasury ${serverFee}`); } catch(e){}
                if (nName) try { dim.runCommand(`scoreboard players add "${nName}" treasury ${nationTax}`); } catch(e){}
                
                if (exData) {
                    exData.revenue += ownerNet;
                    exData.taxPaid += (serverFee + nationTax);
                    world.setDynamicProperty(machineData.linkedExchangeKey, JSON.stringify(exData));
                    try { dim.runCommand(`tellraw "${exData.owner}" {"rawtext":[{"text":"§a[카지노 알림] 손님이 베팅에 실패하여 순수익 ${ownerNet.toLocaleString()}₩이 적립되었습니다. (납부 세금: ${(serverFee+nationTax).toLocaleString()}₩)"}]}`); } catch(e){}
                }
            }
        } else {
            newList.push(key);
        }
    }
    world.setDynamicProperty("active_casino_machines", JSON.stringify(newList));
}, 10);

function showTreasuryUI(player) {
    let pNation = JSON.parse(world.getDynamicProperty("player_nation_" + player.name) || "null");
    let nNames = JSON.parse(world.getDynamicProperty("nation_names") || "{}");
    let nName = pNation ? (nNames[pNation] || pNation.replace("nation_id_", "국가 ")) : "소속 국가 없음";
    
    let nationTreasury = 0;
    if (pNation) { try { nationTreasury = world.scoreboard.getObjective("treasury").getScore(player.dimension.getEntities({name: nName})[0]); } catch(e){} }
    let serverTreasury = 0; try { serverTreasury = world.scoreboard.getObjective("treasury").getScore(player.dimension.getEntities({name: "SERVER_BANK"})[0]); } catch(e){}
    
    const isLeader = player.hasTag("nation_leader") || player.hasTag("admin");
    const form = new ActionFormData().title("§l국고 및 서버 중앙은행 관리")
    .body(`§e[국가 국고 잔액] §f(${nName})\n§b${nationTreasury.toLocaleString()}₩\n\n§6[서버 중앙은행 수수료 잔액]\n§b${serverTreasury.toLocaleString()}₩\n\n§7* 카지노 패배 금액 및 각종 금융 수수료가 이곳에 적립되어 국가 복지 및 서버 운영금으로 사용됩니다.`);
    
    if (pNation && isLeader) form.button("§a국가 국고 출금 (지도자 전용)");
    if (player.hasTag("admin")) form.button("§c서버 중앙은행 출금 (관리자 전용)");
    form.button("닫기");
    
    form.show(player).then(res => {
        if (res.canceled) return;
        if (pNation && isLeader && res.selection === 0) {
            new ModalFormData().title("국가 국고 출금").textField(`출금 가능 금액: ${nationTreasury.toLocaleString()}₩`, "출금할 금액 입력")
            .show(player).then(r => {
                if (r.canceled) return; let amt = parseInt(r.formValues[0]); if(isNaN(amt) || amt <= 0) return;
                if (amt > nationTreasury) { player.sendMessage("§c국고 잔액이 부족합니다."); return; }
                player.dimension.runCommand(`scoreboard players remove "${nName}" treasury ${amt}`);
                player.runCommand(`scoreboard players add @s player_money ${amt}`);
                player.sendMessage(`§a[국고 관리] 국고에서 ${amt.toLocaleString()}₩을 성공적으로 출금했습니다.`);
            });
        } else if (player.hasTag("admin") && ((pNation && isLeader && res.selection === 1) || (!pNation && res.selection === 0))) {
            new ModalFormData().title("서버 중앙은행 출금").textField(`출금 가능 금액: ${serverTreasury.toLocaleString()}₩`, "출금할 금액 입력")
            .show(player).then(r => {
                if (r.canceled) return; let amt = parseInt(r.formValues[0]); if(isNaN(amt) || amt <= 0) return;
                if (amt > serverTreasury) { player.sendMessage("§c서버 중앙은행 잔액이 부족합니다."); return; }
                player.dimension.runCommand(`scoreboard players remove "SERVER_BANK" treasury ${amt}`);
                player.runCommand(`scoreboard players add @s player_money ${amt}`);
                player.sendMessage(`§a[서버 관리] 서버 중앙은행에서 ${amt.toLocaleString()}₩을 성공적으로 출금했습니다.`);
            });
        }
    });
}

// ====== 가이드북 시스템 ======
function showGuideBookUI(player) {
    new ActionFormData().title("§l📖 국가 및 금융 시스템 안내서")
    .body("§eNation Finance Addon§f에 오신 것을 환영합니다!\n이 애드온은 대규모 국가 전쟁, 영토 확장, 그리고 현실적인 금융/경제 시스템을 제공합니다.\n\n§b원하시는 안내 목차를 선택하세요.")
    .button("§a🚩 1. 국가 건국 및 영토 점령 (현수막)")
    .button("§b🏛️ 2. 은행 업무 및 신용/대출 시스템")
    .button("§6🏠 3. 부동산 매매 및 상가 임대업")
    .button("§d🛒 4. POS 상점 개설 및 주식 시장 (IPO)")
    .button("§e🎰 5. 카지노 머신 및 칩 베팅 안내")
    .button("닫기")
    .show(player).then(res => {
        if (res.canceled || res.selection === 5) return;
        let title = ""; let content = "";
        if (res.selection === 0) {
            title = "§l🚩 1. 국가 건국 및 영토 점령";
            content = "§e[국가 건국]§f\n모루에서 바닐라 현수막(Banner)의 이름을 원하는 국가명으로 변경한 뒤, 손에 들고 허공을 클릭(사용)하면 나만의 국가가 건국됩니다!\n\n§e[영토 확장 및 점령]§f\n국가에 소속된 플레이어가 바닥에 현수막을 설치하면, 해당 위치를 중심으로 반경 50블록 내외가 자국의 영토로 편입되며 국경선 파티클이 표시됩니다.";
        } else if (res.selection === 1) {
            title = "§l🏛️ 2. 은행 업무 및 대출";
            content = "§e[은행 NPC 및 계좌]§f\n도시의 은행원 NPC(`nf:bank_npc`)를 클릭하거나 체크/신용카드를 통해 은행 업무를 볼 수 있습니다.\n\n§e[신용 점수 및 대출]§f\n신용 점수(기본 500점)에 따라 최대 한도 내에서 대출이 가능하며, 대출금은 정기적으로 이자(5%)가 발생합니다. 연체 시 신용 점수가 하락하므로 주의하세요.";
        } else if (res.selection === 2) {
            title = "§l🏠 3. 부동산 및 임대업";
            content = "§e[매물 등록]§f\n부동산 지팡이(`nf:property_wand`)로 건물의 양 끝점을 클릭(웅크리고 클릭 시 Pos2)하여 주택이나 상업용 건물을 등록할 수 있습니다.\n\n§e[부동산 중개인 및 임대업]§f\n부동산 중개인 NPC(`nf:realtor_npc`)를 통해 주택을 매수/임대하거나, 상업용 건물을 인수하여 내부 점포(방)마다 월세를 받는 건물주가 될 수 있습니다.";
        } else if (res.selection === 3) {
            title = "§l🛒 4. POS 상점 및 주식 시장";
            content = "§e[POS 단말기]§f\n점포 계약 시 지급되는 POS 단말기(`nf:pos_terminal`)를 설치하여 점주가 되고 상품을 등록해 판매할 수 있습니다.\n\n§e[주식 상장 (IPO)]§f\n무역 및 금융 센터(`nf:trade_port`)나 POS 단말기에서 기업을 주식 시장에 상장하고, 플레이어 간 실시간 주식 거래를 진행할 수 있습니다.";
        } else if (res.selection === 4) {
            title = "§l🎰 5. 카지노 머신 안내";
            content = "§e[카지노 칩 투입]§f\n카지노 칩 1k 또는 10k 아이템을 손에 들고 카지노 머신(`nf:casino_machine`)을 터치하면 금액이 충전됩니다.\n\n§e[게임 작동 및 배당]§f\n금액이 충전된 상태에서 **맨손(또는 칩이 아닌 아이템)**으로 머신을 터치하면 즉시 슬롯이 작동합니다. 승리 시(43%) 2배의 상금이 지급되며, 패배 시 베팅금은 국가 국고 및 서버 중앙은행으로 귀속됩니다.";
        }
        new ActionFormData().title(title).body(content).button("뒤로 가기").show(player).then(r => {
            if (!r.canceled) showGuideBookUI(player);
        });
    });
}

// ====== (convertChestToStockBox 헬퍼 삭제됨 - 직접 설치 방식 회귀) ======

world.afterEvents.playerSpawn.subscribe((event) => {
    const player = event.player;
    if (!event.initialSpawn) return;
    
    system.run(() => {
        let given = JSON.parse(world.getDynamicProperty("guide_given_" + player.name) || "false");
        if (!given) {
            world.setDynamicProperty("guide_given_" + player.name, JSON.stringify(true));
            player.runCommand("give @s nf:guide_book 1");
            player.sendMessage("§a[환영합니다] 인벤토리로 '국가 및 금융 시스템 안내서(설명서 북)'가 지급되었습니다. 손에 들고 클릭하여 시스템 사용법을 확인하세요!");
        }
    });
});

// ====== POS 점주 사업자 및 유통/납품 헬퍼 함수 ======
function getTerminalInventory(dimension, marker) {
    if (!marker) return null;
    let loc = { x: Math.floor(marker.location.x), y: Math.floor(marker.location.y), z: Math.floor(marker.location.z) };
    let block; try { block = dimension.getBlock(loc); } catch(e) { return null; }
    if (!block || block.typeId !== "nf:pos_terminal") return null;
    let comp = block.getComponent("minecraft:inventory") || block.getComponent("inventory");
    return comp ? comp.container : null;
}

function showPosFillUI(player, marker) {
    let inv = getTerminalInventory(player.dimension, marker);
    if (!inv) { player.sendMessage("§c[POS 창고] 계산대 인벤토리에 접근할 수 없습니다."); return; }
    
    const equip = player.getComponent("equippable");
    const mainhand = equip ? equip.getEquipment("Mainhand") : undefined;
    if (!mainhand) { player.sendMessage("§c[POS 창고] 손에 계산대에 넣을 아이템을 들고 실행해 주세요."); return; }
    
    try {
        inv.addItem(mainhand);
        equip.setEquipment("Mainhand", undefined);
        player.sendMessage(`§a[POS 창고] 성공적으로 손에 든 아이템(${mainhand.typeId})을 계산대 창고에 적재했습니다!`);
    } catch(e) {
        player.sendMessage("§c[POS 창고] 계산대 인벤토리가 가득 찼거나 적재할 수 없습니다.");
    }
}

function showPosWithdrawUI(player, marker) {
    let inv = getTerminalInventory(player.dimension, marker);
    if (!inv) { player.sendMessage("§c[POS 창고] 계산대 인벤토리에 접근할 수 없습니다."); return; }
    
    let items = [];
    for (let i = 0; i < inv.size; i++) {
        let item = inv.getItem(i);
        if (item) items.push({ slot: i, item: item });
    }
    
    if (items.length === 0) { player.sendMessage("§c[POS 창고] 계산대 창고가 비어 있습니다."); return; }
    
    const form = new ActionFormData().title("§l계산대 창고 회수").body("회수할 아이템을 선택하세요.");
    for (const it of items) form.button(`§e📦 ${it.item.typeId.replace("minecraft:","")}\n§f수량: ${it.item.amount}개`);
    form.button("닫기");
    
    form.show(player).then(res => {
        if (res.canceled || res.selection === items.length) return;
        const sel = items[res.selection];
        let itemToGive = inv.getItem(sel.slot);
        if (itemToGive) {
            inv.setItem(sel.slot, undefined);
            const playerInvComp = player.getComponent("minecraft:inventory");
            if (playerInvComp && playerInvComp.container) {
                try { playerInvComp.container.addItem(itemToGive); } catch(e) { player.dimension.spawnItem(itemToGive, player.location); }
            } else { player.dimension.spawnItem(itemToGive, player.location); }
            player.sendMessage(`§a[POS 창고] 성공적으로 ${itemToGive.typeId} ${itemToGive.amount}개를 회수했습니다!`);
        }
    });
}

function showPosBusinessRegisterUI(player, marker) {
    let bizId = marker.getDynamicProperty("businessId");
    if (!bizId) {
        bizId = "store_" + Math.floor(Math.random() * 90000 + 10000);
        marker.setDynamicProperty("businessId", bizId);
        player.sendMessage(`§a[사업자 등록 완료] 상점 사업자 ID(${bizId})가 발급되었습니다.\n§7'POS 단말기 (계산대)' 블록 자체가 27칸 창고 역할을 합니다. 호퍼를 연결하거나 점주 메뉴에서 아이템을 채우세요!`);
    } else {
        player.sendMessage(`§e[사업자 안내] 이미 등록된 상점입니다. (사업자 ID: ${bizId})\n§a'POS 단말기 (계산대)' 블록 자체 인벤토리를 통해 상품을 판매하고 관리할 수 있습니다.`);
    }
}

function showPosSupplierRegisterUI(player, marker) {
    let supId = marker.getDynamicProperty("supplierId");
    if (!supId) {
        supId = "supplier_" + Math.floor(Math.random() * 90000 + 10000);
        marker.setDynamicProperty("supplierId", supId);
        let suppliers = JSON.parse(world.getDynamicProperty("suppliers") || "[]");
        suppliers.push({ id: supId, name: player.name + " 물류업체", owner: player.name });
        world.setDynamicProperty("suppliers", JSON.stringify(suppliers));
        player.sendMessage(`§a[납품업체 등록 완료] 납품 사업자 ID(${supId})가 발급되었습니다.\n§7'POS 단말기 (계산대)' 블록 자체가 27칸 물류 창고 역할을 합니다. 호퍼를 연결하거나 점주 메뉴에서 아이템을 채우세요!`);
    } else {
        player.sendMessage(`§e[납품업체 안내] 이미 등록된 납품업체입니다. (사업자 ID: ${supId})\n§a'POS 단말기 (계산대)' 블록 자체 인벤토리를 통해 물류를 배송하고 관리할 수 있습니다.`);
    }
}

function showPosFranchiseUI(player, marker) {
    // 글로벌 목록 + dimension 내 마커 스캔으로 등록된 납품업체를 항상 정확하게 조회
    let suppliers = [];
    try { suppliers = JSON.parse(world.getDynamicProperty("suppliers") || "[]"); } catch(e) { suppliers = []; }
    
    // dimension 스캔으로 supplierId가 있는 마커 추가 (글로벌 목록이 누락됐을 때 보완)
    const allMarkers = player.dimension.getEntities({ type: "nf:pos_marker" });
    for (const m of allMarkers) {
        const supId = m.getDynamicProperty("supplierId");
        if (supId && !suppliers.find(s => s.id === supId)) {
            const supOwner = m.getDynamicProperty("pos_owner") || "알 수 없음";
            suppliers.push({ id: supId, name: supOwner + "의 물류업체", owner: supOwner });
            // 글로벌 목록도 갱신
            world.setDynamicProperty("suppliers", JSON.stringify(suppliers));
        }
    }
    
    const list = [{ id: "supplier_gov", name: "국가 물류센터 (국가장 전용)", owner: "GOV" }, ...suppliers];
    
    const form = new ActionFormData().title("§l납품업체 가맹 계약").body(`§7등록된 납품업체: ${suppliers.length}개\n물품을 공급받을 납품업체를 선택하세요.`);
    for (const s of list) form.button(`§e🚚 ${s.name}`);
    form.button("닫기");
    
    form.show(player).then(res => {
        if (res.canceled || res.selection === list.length) return;
        const sel = list[res.selection];
        marker.setDynamicProperty("franchisedSupplier", sel.id);
        player.sendMessage(`§a[가맹 계약] 성공적으로 '${sel.name}' 업체와 물류 가맹 계약을 체결했습니다!`);
    });
}

function showSupplierCatalogUI(player, marker) {
    let catalog = JSON.parse(marker.getDynamicProperty("supplier_catalog") || "[]");
    const equip = player.getComponent("equippable");
    const mainhand = equip ? equip.getEquipment("Mainhand") : undefined;
    
    const form = new ActionFormData().title("§l납품업체 도매 카탈로그 관리")
    .body(`§7현재 등록된 도매 상품: ${catalog.length}개\n손에 들고 있는 아이템을 도매가로 등록하거나 기존 상품을 삭제하세요.`);
    
    if (mainhand) form.button(`§a📦 손에 든 아이템 등록\n§f(${mainhand.typeId})`);
    for (const c of catalog) form.button(`§c🗑️ 삭제: ${c.name}\n§f도매가: ${c.price.toLocaleString()}₩`);
    form.button("닫기");
    
    form.show(player).then(res => {
        if (res.canceled || res.selection === catalog.length + (mainhand ? 1 : 0)) return;
        if (mainhand && res.selection === 0) {
            new ModalFormData().title("도매 상품 등록").textField("상품의 도매 가격(₩)을 입력하세요.", "예: 500", "500")
            .show(player).then(r => {
                if (r.canceled) return; let price = parseInt(r.formValues[0]); if(isNaN(price) || price < 0) return;
                let existing = catalog.find(c => isSameItem(c.item, mainhand.typeId));
                if (existing) existing.price = price;
                else catalog.push({ item: mainhand.typeId, name: mainhand.nameTag || mainhand.typeId.replace("minecraft:", ""), price: price });
                marker.setDynamicProperty("supplier_catalog", JSON.stringify(catalog));
                player.sendMessage(`§a[도매 등록] 성공적으로 도매 상품을 등록했습니다! (${price.toLocaleString()}₩)`);
                showSupplierCatalogUI(player, marker);
            });
        } else {
            const delIdx = res.selection - (mainhand ? 1 : 0);
            const delItem = catalog[delIdx];
            catalog.splice(delIdx, 1); marker.setDynamicProperty("supplier_catalog", JSON.stringify(catalog));
            player.sendMessage(`§c[도매 삭제] 도매 카탈로그에서 '${delItem.name}' 상품을 삭제했습니다.`);
            showSupplierCatalogUI(player, marker);
        }
    });
}

function showPosOrderUI(player, marker) {
    let supId = marker.getDynamicProperty("franchisedSupplier");
    if (!supId) { player.sendMessage("§c[발주 시스템] 먼저 '납품업체 가맹 계약'을 맺어 주세요."); return; }
    
    if (supId === "supplier_gov") {
        new ModalFormData().title("§l국가 물류센터 발주").textField("발주할 상품 아이템 (예: minecraft:bread)", "예: minecraft:bread").textField("발주 수량", "예: 64", "64")
        .show(player).then(r => {
            if (r.canceled) return; const item = r.formValues[0]; const count = parseInt(r.formValues[1]);
            if (!item || isNaN(count) || count <= 0) return;
            player.sendMessage(`§a[국가 발주] 국가 물류센터로 ${item} ${count}개 발주가 완료되었습니다. (국가 예산 처리)`);
        });
        return;
    }
    
    const allPos = player.dimension.getEntities({ type: "nf:pos_marker" });
    let supMarker = null;
    for (const m of allPos) { if (m.getDynamicProperty("supplierId") === supId) { supMarker = m; break; } }
    
    if (!supMarker) { player.sendMessage("§c[발주 오류] 해당 납품업체 단말기를 찾을 수 없습니다."); return; }
    
    let catalog = JSON.parse(supMarker.getDynamicProperty("supplier_catalog") || "[]");
    if (catalog.length === 0) { player.sendMessage("§c[발주 오류] 해당 납품업체에 등록된 도매 상품 카탈로그가 없습니다."); return; }
    
    let storeName = marker.nameTag.replace("§e", "");
    const form = new ActionFormData().title(`§l상품 발주 요청 - ${supMarker.getDynamicProperty("pos_owner")} 물류업체`).body("발주를 원하는 도매 상품을 선택하세요.");
    for (const c of catalog) form.button(`§e📦 ${c.name}\n§f도매가: ${c.price.toLocaleString()}₩`);
    form.button("닫기");
    
    form.show(player).then(res => {
        if (res.canceled || res.selection === catalog.length) return;
        const selItem = catalog[res.selection];
        
        new ModalFormData().title(`§l발주 수량 입력 - ${selItem.name}`)
        .textField(`도매가: ${selItem.price.toLocaleString()}₩\n발주할 수량을 입력하세요.`, "예: 64", "64")
        .show(player).then(r => {
            if (r.canceled) return; let count = parseInt(r.formValues[0]); if(isNaN(count) || count <= 0) return;
            let totalCost = selItem.price * count;
            
            let money = 0; try { money = world.scoreboard.getObjective("player_money").getScore(player); } catch(e){}
            if (money < totalCost) { player.sendMessage(`§c[발주 실패] 소지금이 부족합니다. (필요 금액: ${totalCost.toLocaleString()}₩ / 현재 소지금: ${money.toLocaleString()}₩)`); return; }
            
            player.runCommand(`scoreboard players remove @s player_money ${totalCost}`);
            
            let orderObj = { storeName: storeName, item: selItem.item, count: count, storeBizId: marker.getDynamicProperty("businessId"), totalCost: totalCost };
            let orders = JSON.parse(supMarker.getDynamicProperty("orders") || "[]");
            orders.push(orderObj); supMarker.setDynamicProperty("orders", JSON.stringify(orders));
            
            let supOwner = supMarker.getDynamicProperty("pos_owner");
            let targetPlayer; try { targetPlayer = player.dimension.getEntities({name: supOwner})[0]; } catch(e){}
            if (targetPlayer) {
                targetPlayer.runCommand("give @s nf:supply_receipt 1");
                targetPlayer.sendMessage(`§6[납품 요청 접수] 가맹점(${storeName})에서 ${selItem.name} ${count}개 발주 요청이 들어왔습니다. (결제 대금: ${totalCost.toLocaleString()}₩)`);
            }
            player.sendMessage(`§a[발주 완료] 총액 ${totalCost.toLocaleString()}₩을 결제하고 납품업체에 발주서를 전송했습니다!`);
        });
    });
}

function safeAddItem(container, itemId, count) {
    let remain = count;
    let actualItemId = itemId.includes(":") ? itemId : "minecraft:" + itemId;
    while (remain > 0) {
        let addAmt = Math.min(remain, 64);
        container.addItem(new ItemStack(actualItemId, addAmt));
        remain -= addAmt;
    }
}

function syncStockCache(dimension, marker) {
    let storeInv = getTerminalInventory(dimension, marker);
    if (!storeInv) return false; // 청크 언로드 상태
    
    // 차감 대기열(pending_deductions) 처리
    let pendingDeduct = []; try { pendingDeduct = JSON.parse(marker.getDynamicProperty("pending_deductions") || "[]"); } catch(e) { pendingDeduct = []; }
    if (pendingDeduct.length > 0) {
        for (const pd of pendingDeduct) {
            let remain = pd.count;
            for (let i = 0; i < storeInv.size; i++) {
                let item = storeInv.getItem(i);
                if (item && isSameItem(item.typeId, pd.item)) {
                    if (item.amount <= remain) { remain -= item.amount; storeInv.setItem(i, undefined); }
                    else { item.amount -= remain; storeInv.setItem(i, item); remain = 0; break; }
                }
            }
        }
        marker.setDynamicProperty("pending_deductions", "[]");
    }
    
    // 현재 계산대 상태 캐싱
    let cacheMap = {};
    for (let i = 0; i < storeInv.size; i++) {
        let item = storeInv.getItem(i);
        if (item) {
            let key = item.typeId; cacheMap[key] = (cacheMap[key] || 0) + item.amount;
        }
    }
    let cacheList = Object.keys(cacheMap).map(k => ({ item: k, count: cacheMap[k] }));
    marker.setDynamicProperty("cached_stock", JSON.stringify(cacheList));
    return true;
}

// ====== 배송 대기열(Queue) 자동 적재 헬퍼 ======
function checkAndProcessPendingSupplies(dimension, marker) {
    syncStockCache(dimension, marker);
    let pending = []; try { pending = JSON.parse(marker.getDynamicProperty("pending_supplies") || "[]"); } catch(e) { pending = []; }
    if (pending.length === 0) return;
    
    let storeInv = getTerminalInventory(dimension, marker); if (!storeInv) return;
    
    let remaining = [];
    for (const p of pending) {
        try { safeAddItem(storeInv, p.item, p.count); } catch(e) { remaining.push(p); }
    }
    marker.setDynamicProperty("pending_supplies", JSON.stringify(remaining));
    syncStockCache(dimension, marker);
}

function isSameItem(id1, id2) {
    if (!id1 || !id2) return false;
    return id1.replace("minecraft:", "") === id2.replace("minecraft:", "");
}

function showPosSupplyProcessUI(player, marker) {
    let orders = JSON.parse(marker.getDynamicProperty("orders") || "[]");
    if (orders.length === 0) { player.sendMessage("§c[납품 처리] 현재 접수된 발주 요청이 없습니다."); return; }
    
    let supInv = getTerminalInventory(player.dimension, marker);
    if (!supInv) { player.sendMessage("§c[납품 처리] 납품업체 계산대 인벤토리에 접근할 수 없습니다."); return; }
    
    const form = new ActionFormData().title("§l발주 접수 목록 및 납품 처리").body("납품을 진행할 가맹점 요청을 선택하세요.");
    for (const o of orders) form.button(`§e🏢 ${o.storeName}\n§f${o.item} x${o.count} (${(o.totalCost||0).toLocaleString()}₩)`);
    form.button("닫기");
    
    form.show(player).then(res => {
        if (res.canceled || res.selection === orders.length) return;
        const order = orders[res.selection];
        
        let hasCount = 0;
        for (let i = 0; i < supInv.size; i++) {
            let item = supInv.getItem(i); if (item && isSameItem(item.typeId, order.item)) hasCount += item.amount;
        }
        
        if (hasCount < order.count) {
            player.sendMessage(`§c[재고 부족] 납품업체 계산대 창고에 ${order.item} 아이템이 부족합니다. (필요: ${order.count}개 / 현재: ${hasCount}개)`); return;
        }
        
        const allPos = player.dimension.getEntities({ type: "nf:pos_marker" });
        let storeMarker = null; for (const m of allPos) { if (m.getDynamicProperty("businessId") === order.storeBizId) { storeMarker = m; break; } }
        if (!storeMarker) { player.sendMessage("§c[납품 오류] 가맹점 단말기를 찾을 수 없습니다."); return; }
        
        // 납품 상자에서 아이템 차감
        let remain = order.count;
        for (let i = 0; i < supInv.size; i++) {
            let item = supInv.getItem(i);
            if (item && isSameItem(item.typeId, order.item)) {
                if (item.amount <= remain) { remain -= item.amount; supInv.setItem(i, undefined); }
                else { item.amount -= remain; supInv.setItem(i, item); remain = 0; break; }
            }
        }
        
        // 납품업체 점주에게 대금 입금
        let supOwner = marker.getDynamicProperty("pos_owner");
        let totalCost = order.totalCost || 0;
        if (supOwner && totalCost > 0) {
            player.dimension.runCommand(`scoreboard players add "${supOwner}" player_money ${totalCost}`);
            try { player.dimension.runCommand(`tellraw "${supOwner}" {"rawtext":[{"text":"§a[정산 완료] 가맹점(${order.storeName}) 납품 대금 ${totalCost.toLocaleString()}₩이 입금되었습니다!"}]}`); } catch(e){}
        }
        
        // 1순위: 가맹점 사장 인벤토리로 즉시 직배송 시도
        let storeOwnerName = storeMarker.getDynamicProperty("pos_owner");
        let targetPlayer; try { targetPlayer = player.dimension.getEntities({name: storeOwnerName})[0]; } catch(e){}
        let directSuccess = false;
        if (targetPlayer) {
            const pInvComp = targetPlayer.getComponent("minecraft:inventory");
            if (pInvComp && pInvComp.container) {
                try {
                    safeAddItem(pInvComp.container, order.item, order.count);
                    directSuccess = true;
                    targetPlayer.sendMessage(`§a[택배 도착] 납품업체에서 발주하신 상품(${order.item} ${order.count}개)이 인벤토리로 직배송되었습니다! 계산대에 호퍼나 메뉴로 채워주세요.`);
                } catch(e) { directSuccess = false; }
            }
        }
        
        // 2순위: 가맹점 계산대 인벤토리로 직접 적재 시도
        if (!directSuccess) {
            let storeInv = getTerminalInventory(player.dimension, storeMarker);
            if (storeInv) {
                try { safeAddItem(storeInv, order.item, order.count); directSuccess = true; } catch(e) { directSuccess = false; }
            }
        }
        
        // 3순위: 언로드 상태일 경우 대기열 보관
        if (!directSuccess) {
            let pending = []; try { pending = JSON.parse(storeMarker.getDynamicProperty("pending_supplies") || "[]"); } catch(e) { pending = []; }
            pending.push({ item: order.item, count: order.count }); storeMarker.setDynamicProperty("pending_supplies", JSON.stringify(pending));
            player.sendMessage(`§a[원격 배송 완료] 가맹점(${order.storeName}) 사장이 오프라인이거나 계산대가 원거리에 있어 배송 대기열에 등록되었습니다.\n§7가맹점 계산대가 로드되거나 점주가 상점을 방문할 때 자동 적재됩니다!`);
        } else {
            player.sendMessage(`§a[납품 완료] 가맹점(${order.storeName})으로 물품 배송 및 적재가 완료되었습니다!`);
        }
        syncStockCache(player.dimension, storeMarker);
        
        orders.splice(res.selection, 1); marker.setDynamicProperty("orders", JSON.stringify(orders));
    });
}

// ====== 키오스크 메인 UI 및 결제 ======
function showKioskMainUI(player, marker) {
    checkAndProcessPendingSupplies(player.dimension, marker);
    let catalog = JSON.parse(marker.getDynamicProperty("pos_catalog") || "[]");
    let cart = JSON.parse(marker.getDynamicProperty("kiosk_cart_" + player.name) || "[]");
    let storeName = marker.nameTag.replace("§e", "");
    
    let total = cart.reduce((acc, c) => acc + (c.price * c.count), 0);
    
    const form = new ActionFormData().title(`§l키오스크 - ${storeName}`)
    .body(`§e[장바구니 총합] §b${total.toLocaleString()}₩\n§7원하시는 상품을 선택하여 담거나 결제를 진행하세요.`);
    
    if (cart.length > 0) form.button("§a💳 카드 결제 진행 (재고 확인)");
    for (const c of catalog) form.button(`§e📦 ${c.name}\n§f가격: ${c.price.toLocaleString()}₩`);
    if (cart.length > 0) form.button("§c🗑️ 장바구니 비우기");
    form.button("닫기");
    
    form.show(player).then(res => {
        if (res.canceled) return;
        let btnIdx = res.selection;
        if (cart.length > 0) {
            if (btnIdx === 0) { processKioskPayment(player, marker, cart, total); return; }
            if (btnIdx === catalog.length + 1) { marker.setDynamicProperty("kiosk_cart_" + player.name, "[]"); player.sendMessage("§a[키오스크] 장바구니를 비웠습니다."); showKioskMainUI(player, marker); return; }
            btnIdx--;
        } else {
            if (btnIdx === catalog.length) return;
        }
        
        const selItem = catalog[btnIdx];
        new ModalFormData().title(`§l상품 담기 - ${selItem.name}`)
        .textField(`가격: ${selItem.price.toLocaleString()}₩\n수량을 입력하세요.`, "예: 1", "1")
        .show(player).then(r => {
            if (r.canceled) return; let count = parseInt(r.formValues[0]); if(isNaN(count) || count <= 0) return;
            let existing = cart.find(c => isSameItem(c.item, selItem.item));
            if (existing) existing.count += count; else cart.push({ item: selItem.item, name: selItem.name, price: selItem.price, count: count });
            marker.setDynamicProperty("kiosk_cart_" + player.name, JSON.stringify(cart));
            player.sendMessage(`§a[장바구니] ${selItem.name} ${count}개를 담았습니다.`);
            showKioskMainUI(player, marker);
        });
    });
}

function processKioskPayment(player, marker, cart, total) {
    const equip = player.getComponent("equippable");
    const mainhand = equip ? equip.getEquipment("Mainhand") : undefined;
    const isCard = mainhand && (mainhand.typeId === "nf:check_card" || mainhand.typeId === "nf:credit_card");
    
    if (!isCard) { player.sendMessage("§c[키오스크 결제] 손에 카드(체크카드 또는 신용카드)를 들고 결제 버튼을 눌러주세요."); return; }
    
    let money = 0; try { money = world.scoreboard.getObjective("player_money").getScore(player); } catch(e){}
    if (money < total) { player.sendMessage("§c[결제 실패] 카드 잔액이 부족합니다."); return; }
    
    let inv = getTerminalInventory(player.dimension, marker);
    
    let isCachedMode = false;
    if (!inv) {
        // 청크 언로드 시 캐시 기반 결제 모드 전환
        let cacheStr = marker.getDynamicProperty("cached_stock");
        if (!cacheStr) { player.sendMessage("§c[결제 실패] 계산대가 언로드되었으며 캐시된 재고 데이터가 없습니다."); return; }
        isCachedMode = true;
    }
    
    if (!isCachedMode) {
        // 실제 인벤토리 검증
        for (const c of cart) {
            let hasCount = 0;
            for (let i = 0; i < inv.size; i++) {
                let item = inv.getItem(i); if (item && isSameItem(item.typeId, c.item)) hasCount += item.amount;
            }
            if (hasCount < c.count) {
                player.sendMessage(`§c재고 부족\n§c품절된 상품이 있습니다. (${c.name} - 필요: ${c.count}개 / 현재 재고: ${hasCount}개)`); return;
            }
        }
        // 실제 인벤토리 차감
        for (const c of cart) {
            let remain = c.count;
            for (let i = 0; i < inv.size; i++) {
                let item = inv.getItem(i);
                if (item && isSameItem(item.typeId, c.item)) {
                    if (item.amount <= remain) { remain -= item.amount; inv.setItem(i, undefined); }
                    else { item.amount -= remain; inv.setItem(i, item); remain = 0; break; }
                }
            }
        }
        syncStockCache(player.dimension, marker);
    } else {
        // 캐시 기반 검증 및 차감 대기열 등록
        let cacheList = JSON.parse(marker.getDynamicProperty("cached_stock") || "[]");
        for (const c of cart) {
            let cached = cacheList.find(x => isSameItem(x.item, c.item));
            let hasCount = cached ? cached.count : 0;
            if (hasCount < c.count) {
                player.sendMessage(`§c재고 부족 (캐시 모드)\n§c품절된 상품이 있습니다. (${c.name} - 필요: ${c.count}개 / 현재 캐시 재고: ${hasCount}개)`); return;
            }
        }
        // 캐시 차감 및 pending_deductions 등록
        let pendingDeduct = JSON.parse(marker.getDynamicProperty("pending_deductions") || "[]");
        for (const c of cart) {
            let cached = cacheList.find(x => isSameItem(x.item, c.item)); if (cached) cached.count -= c.count;
            let existingPD = pendingDeduct.find(x => isSameItem(x.item, c.item));
            if (existingPD) existingPD.count += c.count; else pendingDeduct.push({ item: c.item, count: c.count });
        }
        marker.setDynamicProperty("cached_stock", JSON.stringify(cacheList));
        marker.setDynamicProperty("pending_deductions", JSON.stringify(pendingDeduct));
        player.sendMessage("§e[캐시 결제 모드] 계산대가 원거리에 있어 캐시 데이터 기반으로 결제 및 비동기 재고 차감이 진행되었습니다.");
    }
    
    const serverFee = Math.floor(total * 0.0514);
    let pNation = JSON.parse(world.getDynamicProperty("player_nation_" + marker.getDynamicProperty("pos_owner")) || "null");
    let nNames = JSON.parse(world.getDynamicProperty("nation_names") || "{}");
    let nName = pNation ? (nNames[pNation] || pNation.replace("nation_id_", "국가 ")) : null;
    
    const taxRate = nName ? 10 : 0;
    const nationTax = Math.floor(total * (taxRate / 100));
    const ownerNet = total - serverFee - nationTax;
    
    player.runCommand(`scoreboard players remove @s player_money ${total}`);
    try { player.dimension.runCommand(`scoreboard players add "SERVER_BANK" treasury ${serverFee}`); } catch(e){}
    if (nName) try { player.dimension.runCommand(`scoreboard players add "${nName}" treasury ${nationTax}`); } catch(e){}
    try { player.dimension.runCommand(`scoreboard players add "${marker.getDynamicProperty("pos_owner")}" player_money ${ownerNet}`); } catch(e){}
    
    marker.setDynamicProperty("kiosk_cart_" + player.name, "[]");
    
    player.runCommand("give @s nf:receipt 1");
    let storeName = marker.nameTag.replace("§e", "");
    player.sendMessage(`§a[결제 완료] 총 ${total.toLocaleString()}₩ 결제가 완료되었습니다. 구매 영수증이 발급되었습니다.`);
}

// ====== (커스텀 상자 설치 로직 삭제됨 - 바닐라 상자 전용 유지) ======

function showCasinoExchangeGuestUI(player, exKey, exData) {
    new ActionFormData().title("§l카지노 칩 환전소").body("원하시는 환전 작업을 선택하세요.")
    .button("§e🪙 1k 칩 구매 (1,000₩)")
    .button("§6🪙 10k 칩 구매 (10,000₩)")
    .button("§b💵 칩을 돈으로 환전 (전액)")
    .button("닫기")
    .show(player).then(res => {
        if (res.canceled || res.selection === 3) return;
        let money = 0; try { money = world.scoreboard.getObjective("player_money").getScore(player); } catch(e){}
        
        if (res.selection === 0) {
            if (money < 1000) { player.sendMessage("§c잔액이 부족합니다."); return; }
            player.runCommand("scoreboard players remove @s player_money 1000");
            player.runCommand("give @s nf:chip_1k 1");
            exData.revenue += 1000; world.setDynamicProperty(exKey, JSON.stringify(exData));
            player.sendMessage("§a[환전소] 1,000₩을 1k 칩 1개로 환전했습니다.");
        } else if (res.selection === 1) {
            if (money < 10000) { player.sendMessage("§c잔액이 부족합니다."); return; }
            player.runCommand("scoreboard players remove @s player_money 10000");
            player.runCommand("give @s nf:chip_10k 1");
            exData.revenue += 10000; world.setDynamicProperty(exKey, JSON.stringify(exData));
            player.sendMessage("§a[환전소] 10,000₩을 10k 칩 1개로 환전했습니다.");
        } else if (res.selection === 2) {
            const equip = player.getComponent("equippable");
            const mainhand = equip ? equip.getEquipment("Mainhand") : undefined;
            if (!mainhand || (mainhand.typeId !== "nf:chip_1k" && mainhand.typeId !== "nf:chip_10k")) {
                player.sendMessage("§c손에 환전할 카지노 칩(1k 또는 10k)을 들고 실행해 주세요."); return;
            }
            let val = mainhand.typeId === "nf:chip_1k" ? 1000 : 10000;
            let totalVal = val * mainhand.amount;
            player.runCommand(`scoreboard players add @s player_money ${totalVal}`);
            equip.setEquipment("Mainhand", undefined);
            exData.revenue -= totalVal; world.setDynamicProperty(exKey, JSON.stringify(exData));
            player.sendMessage(`§a[환전소] 칩을 성공적으로 환전하여 ${totalVal.toLocaleString()}₩을 입금받았습니다.`);
        }
    });
}
