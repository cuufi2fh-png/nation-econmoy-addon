scriptevent nf:loan repay
